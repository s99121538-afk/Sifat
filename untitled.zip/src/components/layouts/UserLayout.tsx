import { Outlet, NavLink } from 'react-router-dom';
import { Home, Wallet, Store, User, History } from 'lucide-react';
import { cn } from '../../lib/utils';
import FloatingSupport from '../FloatingSupport';
import { useAuthStore } from '../../store/useAuthStore';

export default function UserLayout() {
  const { user, profile } = useAuthStore();
  const navItems = [
    { icon: Home, label: 'Home', path: '/dashboard' },
    { icon: Store, label: 'Store', path: '/store' },
    { icon: History, label: 'History', path: '/history' },
    { icon: User, label: 'Profile', path: '/profile' },
  ];

  const email = user?.email || profile?.email || 'user@example.com';
  const initial = email.charAt(0).toUpperCase();

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto relative shadow-2xl overflow-hidden">
      {/* Top Header Placeholder */}
      <header className="bg-white px-4 py-3 pb-4 shadow-sm z-10 flex justify-between items-center">
        <h1 className="text-xl font-bold text-gray-800 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
          Account Hub
        </h1>
        <div className="flex space-x-3">
           <NavLink to="/profile" className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center hover:bg-blue-200 transition-colors">
             <span className="text-blue-700 font-medium">{initial}</span>
           </NavLink>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-20 scrollbar-hide relative">
        <Outlet />
      </main>

      <FloatingSupport />

      {/* Bottom Navigation Navbar */}
      <nav className="fixed bottom-0 w-full max-w-md mx-auto bg-white border-t border-gray-100 px-6 py-2 shadow-[0_-4px_20px_rgba(0,0,0,0.05)] z-50">
        <div className="flex justify-between items-center">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-300",
                  isActive ? "text-blue-600 scale-110" : "text-gray-400 hover:text-gray-600"
                )
              }
            >
              <item.icon className="w-6 h-6 mb-1" strokeWidth={2.5} />
              <span className="text-[10px] font-semibold">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
