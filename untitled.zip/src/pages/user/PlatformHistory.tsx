import { useState } from 'react';
import { History, Briefcase, CheckSquare, ShoppingCart, Info, Mail, MessageSquare, Facebook, Instagram, ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { useDailyTaskStore } from '../../store/useDailyTaskStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useJobStore } from '../../store/useJobStore';
import { useTransactionStore } from '../../store/useTransactionStore';
import { format } from 'date-fns';

type HistoryTab = 'gmail' | 'whatsapp' | 'facebook' | 'instagram' | 'withdraw' | 'deposit';

export default function PlatformHistory() {
  const { user, profile } = useAuthStore();
  const userId = user?.id || profile?.id || 'mock-user-id';
  const { submissions: jobSubmissions, jobs } = useJobStore();
  const { submissions: taskSubmissions, tasks } = useDailyTaskStore();
  const { transactions } = useTransactionStore();

  const [activeTab, setActiveTab] = useState<HistoryTab>('gmail');

  // Filter items that match the category for jobs/tasks
  const getSubmissionsByCategory = (categorySearch: string) => {
    const searchLow = categorySearch.toLowerCase();
    
    let matchedJobs = (jobSubmissions || []).filter(s => s.userId === userId).filter(s => {
      const job = jobs.find(j => j.id === s.jobId);
      const titleMatch = (s.jobTitle || '').toLowerCase().includes(searchLow) || (job?.title || '').toLowerCase().includes(searchLow);
      const catMatch = (job?.category || '').toLowerCase().includes(searchLow);
      return titleMatch || catMatch;
    });

    const matchedJobsMapped = matchedJobs
      .map(s => ({ ...s, job: jobs.find(j => j.id === s.jobId) }))
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    
    let matchedTasks = (taskSubmissions || []).filter(s => s.userId === userId).filter(s => {
      const task = tasks.find(t => t.id === s.taskId);
      const titleMatch = (s.taskTitle || '').toLowerCase().includes(searchLow) || (task?.title || '').toLowerCase().includes(searchLow);
      const catMatch = (task?.category || '').toLowerCase().includes(searchLow);
      return titleMatch || catMatch;
    });

    const matchedTasksMapped = matchedTasks
      .map(s => ({ ...s, task: tasks.find(t => t.id === s.taskId) }))
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    
    return { jobs: matchedJobsMapped, tasks: matchedTasksMapped };
  };

  const getTransactionsByType = (type: 'withdraw' | 'deposit') => {
    return (transactions || []).filter(t => t.userId === userId && t.type === type).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  };

  const tabOptions = [
    { id: 'gmail', label: 'Gmail', icon: Mail },
    { id: 'whatsapp', label: 'WhatsApp', icon: MessageSquare },
    { id: 'facebook', label: 'Facebook', icon: Facebook },
    { id: 'instagram', label: 'Instagram', icon: Instagram },
    { id: 'withdraw', label: 'Withdraw', icon: ArrowUpRight },
    { id: 'deposit', label: 'Deposit', icon: ArrowDownRight },
  ] as const;

  const currentCategoryData = ['gmail', 'whatsapp', 'facebook', 'instagram'].includes(activeTab) 
    ? getSubmissionsByCategory(activeTab) 
    : { jobs: [], tasks: [] };

  const currentTransactionData = ['withdraw', 'deposit'].includes(activeTab) 
    ? getTransactionsByType(activeTab as 'withdraw' | 'deposit')
    : [];

  return (
    <div className="p-4 mb-24 max-w-lg mx-auto min-h-screen">
      <div className="flex items-center mb-6">
        <div className="bg-blue-100 p-3 rounded-2xl mr-4">
          <History className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">History</h1>
          <p className="text-gray-500 text-sm">Your platform activities</p>
        </div>
      </div>

      {/* Scrollable Tabs */}
      <div className="flex space-x-2 bg-white p-2 rounded-2xl shadow-sm mb-6 border border-gray-100 overflow-x-auto scrollbar-hide">
        {tabOptions.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as HistoryTab)}
              className={`flex items-center space-x-1.5 py-2.5 px-4 rounded-xl font-bold transition-all whitespace-nowrap ${isActive ? 'bg-blue-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {['gmail', 'whatsapp', 'facebook', 'instagram'].includes(activeTab) && (
        <div className="space-y-4">
          {currentCategoryData.jobs.map(sub => (
            <div key={`job-${sub.id}`} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 relative overflow-hidden">
                <div className={`absolute top-0 right-0 text-white text-xs font-bold px-3 py-1 rounded-bl-xl shadow-sm ${
                  sub.status === 'SUCCESS' ? 'bg-green-500' :
                  sub.status === 'REJECTED' ? 'bg-red-500' : 'bg-yellow-500'
                }`}>
                  {sub.status.charAt(0).toUpperCase() + sub.status.slice(1)}
                </div>
                <h3 className="font-bold text-gray-900 text-lg mb-1 mr-16">{sub.jobTitle || sub.job?.title || 'Unknown Job'}</h3>
                <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded uppercase font-bold mb-3">{activeTab}</span>
                <p className="text-sm text-gray-500 mb-3">{sub.createdAt ? format(new Date(sub.createdAt), 'MMMM dd, yyyy - hh:mm a') : 'Unknown Date'}</p>
                <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                  <p className="text-sm text-gray-700"><strong>Proof:</strong> {sub.proofText}</p>
                </div>
            </div>
          ))}
          
          {currentCategoryData.tasks.map(sub => (
            <div key={`task-${sub.id}`} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 relative overflow-hidden">
                <div className={`absolute top-0 right-0 text-white text-xs font-bold px-3 py-1 rounded-bl-xl shadow-sm ${
                  sub.status === 'SUCCESS' ? 'bg-green-500' :
                  sub.status === 'REJECTED' ? 'bg-red-500' : 'bg-yellow-500'
                }`}>
                  {sub.status.charAt(0).toUpperCase() + sub.status.slice(1)}
                </div>
                <h3 className="font-bold text-gray-900 text-lg mb-1 mr-16">{sub.taskTitle || sub.task?.title || 'Unknown Task'}</h3>
                 <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded uppercase font-bold mb-3">{activeTab}</span>
                <p className="text-sm text-gray-500 mb-3">{sub.createdAt ? format(new Date(sub.createdAt), 'MMMM dd, yyyy - hh:mm a') : 'Unknown Date'}</p>
                <div className="bg-gray-50 p-3 rounded-xl border border-gray-100">
                  <p className="text-sm text-gray-700"><strong>Proof:</strong> {sub.proofText}</p>
                </div>
            </div>
          ))}

          {currentCategoryData.jobs.length === 0 && currentCategoryData.tasks.length === 0 && (
            <div className="text-center py-10 bg-white rounded-3xl border border-dashed border-gray-200">
              <p className="text-gray-500 font-medium">No history found for {activeTab}.</p>
            </div>
          )}
        </div>
      )}

      {['withdraw', 'deposit'].includes(activeTab) && (
        <div className="space-y-4">
          {currentTransactionData.map(transaction => (
            <div key={transaction.id} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100 relative overflow-hidden">
                <div className={`absolute top-0 right-0 text-white text-xs font-bold px-3 py-1 rounded-bl-xl shadow-sm ${
                  transaction.status === 'success' ? 'bg-green-500' :
                  transaction.status === 'rejected' ? 'bg-red-500' : 'bg-yellow-500'
                }`}>
                  {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                </div>
                <h3 className="font-bold text-gray-900 text-lg mb-1 uppercase tracking-wide">
                  {transaction.type === 'withdraw' ? 'Withdrawal' : 'Deposit'}
                </h3>
                <h4 className="text-xl font-black text-blue-700 mb-3">৳{transaction.amount.toFixed(2)}</h4>
                
                <div className="bg-gray-50 p-3 rounded-xl border border-gray-100 text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Method:</span>
                    <span className="font-bold text-gray-800">{transaction.method}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium text-xs">A/C:</span>
                    <span className="font-bold text-gray-700 text-xs">{transaction.accountNumber}</span>
                  </div>
                  <div className="flex justify-between pt-2 mt-2 border-t border-gray-200">
                    <span className="text-gray-400 font-medium text-xs">Date:</span>
                    <span className="font-bold text-gray-600 text-xs">
                      {transaction.createdAt ? format(new Date(transaction.createdAt), 'dd MMM yyyy, hh:mm a') : 'Unknown'}
                    </span>
                  </div>
                </div>
            </div>
          ))}

          {currentTransactionData.length === 0 && (
            <div className="text-center py-10 bg-white rounded-3xl border border-dashed border-gray-200">
              <p className="text-gray-500 font-medium">No {activeTab} history found.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
