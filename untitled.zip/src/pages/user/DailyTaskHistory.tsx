import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, ArrowLeft, Info, HelpCircle } from 'lucide-react';
import { useDailyTaskStore } from '../../store/useDailyTaskStore';
import { useAuthStore } from '../../store/useAuthStore';
import { format } from 'date-fns';

export default function DailyTaskHistory() {
  const navigate = useNavigate();
  const { submissions } = useDailyTaskStore();
  const { user, profile } = useAuthStore();
  const userId = user?.id || profile?.id || 'mock-user-id';
  
  const [selectedRejectReason, setSelectedRejectReason] = useState<string | null>(null);

  const mySubmissions = submissions.filter(s => s.userId === userId).sort((a, b) => (b.createdAt ? new Date(b.createdAt).getTime() : 0) - (a.createdAt ? new Date(a.createdAt).getTime() : 0));

  return (
    <div className="p-4 mb-24 max-w-lg mx-auto bg-[#eef4ff] min-h-screen">
      <div className="flex items-center space-x-3 mb-6 bg-white p-4 rounded-2xl shadow-sm">
        <button onClick={() => navigate(-1)} className="p-2 bg-gray-50 rounded-full hover:bg-gray-100 transition-colors">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="text-xl font-bold text-teal-900">আমার কাজের হিস্টোরি (Task History)</h1>
      </div>

      <div className="space-y-4">
        {mySubmissions.length === 0 ? (
          <div className="text-center py-10 bg-white rounded-3xl shadow-sm">
            <p className="text-gray-500 font-medium">আপনার কাজের কোনো হিস্টোরি নেই।</p>
          </div>
        ) : (
          mySubmissions.map(sub => {
            const dateStr = sub.createdAt ? format(new Date(sub.createdAt), 'dd MMM, yyyy') : 'Unknown Date';
            
            return (
              <div key={sub.id} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
                <div className="flex items-start space-x-4">
                  <div className="bg-[#f0f5ff] min-w-[3.5rem] w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0">
                    <Briefcase className="w-6 h-6 text-teal-600" />
                  </div>
                  
                  <div className="flex-1 min-w-0 pt-1">
                    <h3 className="font-bold text-gray-800 text-[15px] mb-2 leading-snug">{sub.taskTitle || 'Unknown Task'}</h3>
                    <div className="flex items-center text-gray-500 text-xs font-medium mb-3">
                      <span className="flex items-center">
                        <span className="mr-1">📅</span> {dateStr}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-teal-800 font-bold text-lg">৳{(sub.taskPrice || 0).toFixed(2)}</span>
                      
                      {sub.status === 'PENDING' && (
                        <div className="bg-amber-100 text-amber-600 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide">
                          Pending
                        </div>
                      )}
                      
                      {sub.status === 'SUCCESS' && (
                        <div className="bg-green-100 text-green-600 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide">
                          Success
                        </div>
                      )}
                      
                      {sub.status === 'REJECTED' && (
                        <div className="flex items-center space-x-2">
                           <button 
                             onClick={() => setSelectedRejectReason(sub.rejectReason || 'No reason provided.')}
                             className="text-red-500 p-1 bg-red-50 rounded-full hover:bg-red-100"
                           >
                             <HelpCircle className="w-4 h-4" />
                           </button>
                           <div className="bg-red-100 text-red-600 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide cursor-pointer"
                                onClick={() => setSelectedRejectReason(sub.rejectReason || 'No reason provided.')}>
                             Rejected
                           </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Reject Reason Modal */}
      {selectedRejectReason && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl transform transition-all">
            <div className="flex items-center text-red-600 mb-4">
              <Info className="w-6 h-6 mr-2" />
              <h3 className="text-xl font-bold">Reject Reason</h3>
            </div>
            <p className="text-gray-700 font-medium mb-6">
              {selectedRejectReason}
            </p>
            <button
              onClick={() => setSelectedRejectReason(null)}
              className="w-full bg-gray-100 text-gray-800 font-bold py-3.5 rounded-xl hover:bg-gray-200 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
