import { useState } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { User, Mail, Lock, Save, LogOut, Users, Copy, Award } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Profile() {
  const { user, profile, setUser, logout } = useAuthStore();
  const [fullName, setFullName] = useState(profile?.full_name || profile?.name || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  const email = user?.email || profile?.email || 'user@example.com';
  const initial = email.charAt(0).toUpperCase();

  const handleCopyCode = () => {
    if (profile?.referralCode) {
      navigator.clipboard.writeText(profile.referralCode);
      toast.success("Referral code copied!");
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdating(true);

    try {
      if (newPassword) {
        if (!currentPassword) {
          toast.error("বর্তমান পাসওয়ার্ড দিতে হবে নতুন পাসওয়ার্ড সেট করার জন্য।");
          setIsUpdating(false);
          return;
        }
      }
      
      // Verify password if provided (either for name change or password change)
      // Or just verify if they want to change password
      if (newPassword && currentPassword && isSupabaseConfigured && user?.email) {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: user.email,
          password: currentPassword
        });

        if (signInError) {
          toast.error("বর্তমান পাসওয়ার্ড ভুল।");
          setIsUpdating(false);
          return;
        }
      }

      let updateFields: any = {};
      if (newPassword) {
        updateFields.password = newPassword;
      }
      if (fullName) {
        updateFields.data = { full_name: fullName, name: fullName };
      }

      if (isSupabaseConfigured && Object.keys(updateFields).length > 0) {
        const { error: updateError } = await supabase.auth.updateUser(updateFields);

        if (updateError) {
          toast.error("আপডেট করতে সমস্যা হয়েছে: " + updateError.message);
          setIsUpdating(false);
          return;
        }
      }

      // Update local state mock
      setUser(user, { ...profile, full_name: fullName, name: fullName });
      toast.success("প্রোফাইল সফলভাবে আপডেট করা হয়েছে!");
      setCurrentPassword('');
      setNewPassword('');

    } catch (error) {
      toast.error("কোথাও একটি সমস্যা হয়েছে।");
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="p-4 mb-24 max-w-lg mx-auto">
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-blue-50 relative mt-4">
        <div className="flex flex-col items-center justify-center text-center">
          <div className="flex items-center space-x-2 text-blue-800 mb-1">
            <User className="w-8 h-8 fill-current" />
            <h2 className="text-3xl font-bold">Edit Profile</h2>
          </div>
          <p className="text-gray-500 font-medium text-sm mb-6">আপনার প্রোফাইলের তথ্য আপডেট করুন</p>

          <div className="relative mb-6">
            <div className="w-28 h-28 bg-gray-100 rounded-full flex items-center justify-center text-4xl font-bold text-gray-400 border-4 border-white shadow-xl">
              {initial}
            </div>
          </div>
        </div>

        {/* Referral info removed to separate page */}

        <form onSubmit={handleUpdate} className="space-y-5">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <User className="h-5 w-5 text-blue-500 fill-blue-500" />
              </div>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Enter your full name"
                className="w-full pl-11 pr-4 py-3 bg-[#f5f8ff] border border-transparent rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all font-medium text-gray-800"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              Email <span className="text-red-500 font-normal">(Immutable)</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-blue-500 fill-blue-500" />
              </div>
              <input
                type="email"
                readOnly
                value={email}
                className="w-full pl-11 pr-4 py-3 bg-[#f5f8ff] border border-transparent rounded-2xl text-gray-500 outline-none font-medium cursor-not-allowed"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              Current Password <span className="text-gray-400 font-normal">(Required to set new)</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-blue-500 fill-blue-500" />
              </div>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter current password"
                className="w-full pl-11 pr-4 py-3 bg-[#f5f8ff] border border-transparent rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all font-medium text-gray-800 placeholder-gray-400"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              New Password <span className="text-gray-400 font-normal">(Keep blank if no change)</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-blue-500 fill-blue-500" />
              </div>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="******"
                className="w-full pl-11 pr-4 py-3 bg-[#f5f8ff] border border-transparent rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all font-medium text-gray-800 tracking-widest placeholder-gray-400"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isUpdating}
            className="w-full bg-gradient-to-r from-blue-700 to-blue-500 text-white rounded-full mt-6 py-4 font-bold text-base hover:from-blue-800 hover:to-blue-600 focus:ring-4 focus:ring-blue-200 transition-all flex justify-center items-center space-x-2 shadow-lg hover:shadow-xl disabled:opacity-70 uppercase tracking-wide"
          >
            <Save className="w-5 h-5 mr-1" />
            <span>UPDATE INFORMATION</span>
          </button>
        </form>

        <button
          onClick={logout}
          className="w-full mt-4 bg-red-50 text-red-600 rounded-full py-3.5 font-bold text-sm hover:bg-red-100 transition-colors flex justify-center items-center space-x-2 border border-red-100 uppercase tracking-wide"
        >
          <LogOut className="w-5 h-5" />
          <span>LOGOUT</span>
        </button>
      </div>
    </div>
  );
}
