import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Upload } from 'lucide-react';
import { useDailyTaskStore } from '../../store/useDailyTaskStore';
import { useAuthStore } from '../../store/useAuthStore';
import toast from 'react-hot-toast';

export default function DailyTaskDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { tasks, submitTask } = useDailyTaskStore();
  const { user, profile } = useAuthStore();
  
  const task = tasks.find(j => j.id === id);
  
  const [proofText, setProofText] = useState('');
  const [proofImage, setProofImage] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!task) {
    return (
      <div className="p-4 flex flex-col items-center justify-center min-h-screen text-center">
        <p className="text-gray-500 font-medium mb-4">Task not found or no longer available.</p>
        <button onClick={() => navigate('/daily-tasks')} className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold">Go Back</button>
      </div>
    );
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const objectUrl = URL.createObjectURL(file);
      setProofImage(objectUrl);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (task.requireTextProof && !proofText) {
      toast.error('Please provide text proof as required.');
      return;
    }
    if (task.requireScreenshot && !proofImage) {
      toast.error('Please provide a screenshot as required.');
      return;
    }
    if (!task.requireTextProof && !task.requireScreenshot && !proofText && !proofImage) {
       toast.error('Please submit some form of proof.');
       return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      submitTask({
        id: crypto.randomUUID(),
        taskId: task.id,
        userId: user?.id || profile?.id || 'mock-user-id',
        taskTitle: task.title,
        taskPrice: task.price,
        proofText,
        proofImage,
        status: 'PENDING',
        createdAt: new Date().toISOString()
      });
      setIsSubmitting(false);
      toast.success('Task proof submitted successfully!');
      navigate('/daily-task-history');
    }, 1000);
  };

  return (
    <div className="p-4 mb-24 max-w-lg mx-auto bg-gray-50 min-h-screen">
      <div className="flex items-center space-x-3 mb-6 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
        <button onClick={() => navigate(-1)} className="p-2 bg-gray-50 rounded-full hover:bg-gray-100 transition-colors">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">Task Details</h1>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-teal-50 mb-6">
        <div className="inline-block bg-teal-100 text-teal-800 px-3 py-1 rounded-full text-xs font-bold mb-4">
          {task.category}
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">{task.title}</h2>
        <div className="flex items-center space-x-4 mb-6 text-sm font-medium">
          <span className="text-teal-600 bg-teal-50 px-3 py-1 rounded-lg">Pay: ৳{task.price.toFixed(2)}</span>
          <span className="text-gray-500">{task.totalSpots - task.filledSpots} spots left</span>
        </div>
        
        <div className="bg-[#f2fcfb] p-4 rounded-2xl border border-teal-50">
          <h3 className="font-bold text-teal-900 mb-2">Description / Instructions</h3>
          <p className="text-gray-700 whitespace-pre-wrap text-sm leading-relaxed mb-4">
            {task.description}
          </p>
          
          {task.instructionImage && (
            <div className="mt-4">
              <h4 className="font-bold text-teal-900 text-sm mb-2">Example / Reference</h4>
              <img src={task.instructionImage} alt="Instruction" className="rounded-xl w-full object-cover border border-teal-100" />
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-teal-50">
        <h3 className="font-bold text-gray-800 mb-4 text-lg">Submit Proof</h3>
        <form onSubmit={handleSubmit} className="space-y-5">
           {task.requireTextProof && (
             <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Text Proof (Link / Username / Info) <span className="text-red-500">*</span></label>
              <textarea
                value={proofText}
                onChange={(e) => setProofText(e.target.value)}
                placeholder="Provide requested details or links..."
                rows={4}
                className="w-full px-4 py-3 bg-[#f5f8ff] border border-transparent rounded-2xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all font-medium text-gray-800 resize-none"
              />
            </div>
           )}

          {task.requireScreenshot && (
            <div>
               <label className="block text-sm font-bold text-gray-700 mb-2">Screenshot Proof <span className="text-red-500">*</span></label>
               {proofImage ? (
                 <div className="relative rounded-2xl overflow-hidden border border-gray-200">
                    <img src={proofImage} alt="Proof" className="w-full object-cover max-h-48" />
                    <button 
                      type="button"
                      onClick={() => setProofImage('')}
                      className="absolute top-2 right-2 bg-red-500 text-white text-xs px-3 py-1 rounded-full font-bold shadow-sm hover:bg-red-600"
                    >
                      Remove
                    </button>
                 </div>
               ) : (
                  <div className="relative">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <div className="w-full bg-[#f5f8ff] border-2 border-dashed border-teal-200 rounded-2xl py-8 flex flex-col items-center justify-center text-teal-500 hover:bg-teal-50 transition-colors">
                      <Upload className="w-8 h-8 mb-2" />
                      <span className="font-medium">Upload Screenshot</span>
                    </div>
                  </div>
               )}
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-teal-700 to-teal-500 text-white rounded-full py-4 font-bold text-base hover:from-teal-800 hover:to-teal-600 transition-all flex justify-center items-center space-x-2 shadow-lg disabled:opacity-70 mt-4"
          >
            {isSubmitting ? (
              <span className="animate-pulse">Submitting...</span>
            ) : (
              <>
                <span>SUBMIT WORK</span>
                <Send className="w-5 h-5" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
