import { useState } from 'react';
import { ShoppingCart, Package, Info, History } from 'lucide-react';
import { useStoreItemStore } from '../../store/useStoreItemStore';
import { useAuthStore } from '../../store/useAuthStore';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

export default function Store() {
  const { items, purchases, addPurchase } = useStoreItemStore();
  const { user, profile, updateBalance } = useAuthStore();
  const userId = user?.id || profile?.id || 'mock-user-id';
  const balance = profile?.balance || 0;

  const [activeTab, setActiveTab] = useState<'shop' | 'purchases'>('shop');
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [isBuyModalOpen, setIsBuyModalOpen] = useState(false);

  const myPurchases = purchases.filter(p => p.userId === userId).sort((a,b) => (b.purchasedAt ? new Date(b.purchasedAt).getTime() : 0) - (a.purchasedAt ? new Date(a.purchasedAt).getTime() : 0));

  const handleBuyClick = (item: any) => {
    setSelectedItem(item);
    setIsBuyModalOpen(true);
  };

  const confirmPurchase = async () => {
    if (!selectedItem) return;

    if (balance < selectedItem.price) {
      toast.error('Insufficient balance!');
      return;
    }

    try {
      await updateBalance(-selectedItem.price);
      
      addPurchase({
        id: crypto.randomUUID(),
        userId,
        itemId: selectedItem.id,
        itemTitle: selectedItem.title,
        price: selectedItem.price,
        content: selectedItem.content,
        purchasedAt: new Date().toISOString()
      });

      toast.success('Purchase successful! Item added to My Items.');
      setIsBuyModalOpen(false);
      setActiveTab('purchases');
    } catch (err) {
      toast.error('Failed to process purchase');
    }
  };

  return (
    <div className="p-4 mb-24 max-w-lg mx-auto bg-[#f8fbff] min-h-screen">
      <div className="flex bg-white rounded-2xl p-1 shadow-sm mb-6 border border-gray-100">
        <button
          onClick={() => setActiveTab('shop')}
          className={`flex-1 flex items-center justify-center space-x-2 py-3 rounded-xl font-bold transition-all ${activeTab === 'shop' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
        >
          <ShoppingCart className="w-5 h-5" />
          <span>Shop</span>
        </button>
        <button
          onClick={() => setActiveTab('purchases')}
          className={`flex-1 flex items-center justify-center space-x-2 py-3 rounded-xl font-bold transition-all ${activeTab === 'purchases' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
        >
          <History className="w-5 h-5" />
          <span>My Items</span>
        </button>
      </div>

      {activeTab === 'shop' && (
        <div className="space-y-4">
          {items.map(item => (
            <div key={item.id} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
               {item.imageUrl && (
                 <img src={item.imageUrl} alt={item.title} className="w-full h-40 object-cover rounded-2xl mb-4" />
               )}
               <div className="flex justify-between items-start mb-2">
                 <h3 className="font-bold text-gray-900 text-lg">{item.title}</h3>
                 <span className="bg-indigo-100 text-indigo-800 font-bold px-3 py-1 rounded-lg text-sm whitespace-nowrap">৳{item.price.toFixed(2)}</span>
               </div>
               <p className="text-gray-600 text-sm mb-4 leading-relaxed">{item.description}</p>
               <button 
                 onClick={() => handleBuyClick(item)}
                 className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold flex justify-center items-center space-x-2 hover:bg-indigo-700 transition"
               >
                 <ShoppingCart className="w-5 h-5" />
                 <span>Buy Now</span>
               </button>
            </div>
          ))}
          {items.length === 0 && (
             <div className="text-center py-10">
               <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
               <p className="text-gray-500 font-medium">No items available in the store right now.</p>
             </div>
          )}
        </div>
      )}

      {activeTab === 'purchases' && (
        <div className="space-y-4">
          {myPurchases.map(purchase => (
            <div key={purchase.id} className="bg-white p-5 rounded-3xl shadow-sm border border-indigo-100 overflow-hidden relative">
               <div className="absolute top-0 right-0 bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-bl-xl shadow-sm">
                 Purchased
               </div>
               <h3 className="font-bold text-indigo-900 text-lg mb-2 mr-16">{purchase.itemTitle}</h3>
               <div className="text-xs text-gray-500 mb-4 font-medium flex items-center">
                 <span>Purchased on {purchase.purchasedAt ? format(new Date(purchase.purchasedAt), 'dd MMM yyyy') : 'Unknown Date'}</span>
                 <span className="mx-2">•</span>
                 <span>৳{purchase.price}</span>
               </div>
               <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100">
                 <div className="flex items-center text-indigo-800 mb-2 font-bold text-sm">
                   <Info className="w-4 h-4 mr-1.5" /> Special Content / Link
                 </div>
                 <p className="text-indigo-900 whitespace-pre-wrap text-sm select-all">
                   {purchase.content}
                 </p>
               </div>
            </div>
          ))}
          {myPurchases.length === 0 && (
             <div className="text-center py-10 bg-white rounded-3xl border border-gray-100">
               <p className="text-gray-500 font-medium">You haven't bought anything yet.</p>
             </div>
          )}
        </div>
      )}

      {isBuyModalOpen && selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-xl font-bold text-gray-900 mb-2">Confirm Purchase</h3>
            <p className="text-gray-600 mb-6 font-medium">Are you sure you want to buy <strong>{selectedItem.title}</strong> for <span className="text-indigo-700 font-bold">৳{selectedItem.price}</span>?</p>
            <div className="flex space-x-3">
              <button 
                onClick={confirmPurchase}
                className="flex-1 bg-indigo-600 text-white font-bold py-3.5 rounded-xl hover:bg-indigo-700 transition"
              >
                Confirm
              </button>
              <button 
                onClick={() => setIsBuyModalOpen(false)}
                className="flex-1 bg-gray-100 text-gray-700 font-bold py-3.5 rounded-xl hover:bg-gray-200 transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
