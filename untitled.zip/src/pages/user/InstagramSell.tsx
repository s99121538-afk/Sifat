import { useState } from 'react';
import { Copy, PlayCircle, Send, Lock, Instagram, AtSign, Shield } from 'lucide-react';
import toast from 'react-hot-toast';
import { useSettingsStore } from '../../store/useSettingsStore';
import { useDailyTaskStore } from '../../store/useDailyTaskStore';
import { useAuthStore } from '../../store/useAuthStore';
import { isToday } from 'date-fns';

export default function InstagramSell() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [twoFaKey, setTwoFaKey] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const adminSettings = useSettingsStore((state) => state.instagramSetting);
  const { submitSocialAccount, submissions } = useDailyTaskStore();
  const { profile, user } = useAuthStore();
  const userId = user?.id || profile?.id || 'mock-user-id';

  const submittedCount = submissions.filter(s => s.userId === userId && s.taskId === 'social-instagram' && s.createdAt && isToday(new Date(s.createdAt))).length;

  const handleCopy = () => {
    navigator.clipboard.writeText(adminSettings.todaysPassword || '');
    toast.success("Password copied to clipboard!");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    submitSocialAccount({
      id: crypto.randomUUID(),
      taskId: 'social-instagram',
      userId,
      proofText: `Username: ${username}\nPassword: ${password}\n2FA/Backup: ${twoFaKey}`,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      taskTitle: 'Instagram Account',
      taskPrice: Number(adminSettings.rate) || 0
    });

    toast.success("Account submitted successfully!");
    setUsername('');
    setPassword('');
    setTwoFaKey('');
    setIsSubmitting(false);
  };

  return (
    <div className="p-4 space-y-4 mb-24">
      {/* Notice Marquee */}
      <div className="bg-blue-600 text-white rounded-lg p-3 flex overflow-hidden shadow-md items-center">
        <span className="font-bold mr-2 whitespace-nowrap">📢</span>
        <div className="flex-1 overflow-hidden relative flex items-center">
          <p className="animate-marquee whitespace-nowrap text-sm font-medium">
            {adminSettings.notice}
          </p>
        </div>
      </div>

      {/* Tutorial Button */}
      <a 
        href={adminSettings.tutorialLink}
        target="_blank"
        rel="noopener noreferrer"
        className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex items-center justify-between hover:shadow-md transition-all group"
      >
        <div className="flex items-center space-x-3">
           <img src="https://img.icons8.com/color/512/instagram-new.png" className="w-8 h-8 object-contain" alt="Instagram" referrerPolicy="no-referrer" />
           <span className="font-bold text-gray-800">INSTAGRAM সেল টিউটোরিয়াল!</span>
        </div>
        <div className="bg-blue-600 text-white p-2 rounded-full group-hover:scale-110 transition-transform shadow-md">
          <PlayCircle className="w-6 h-6" />
        </div>
      </a>

      {/* Info Header */}
      <div className="bg-gradient-to-br from-blue-700 to-blue-500 rounded-3xl p-6 text-white shadow-lg text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10">
          <Instagram className="w-32 h-32 -mr-8 -mt-8" />
        </div>
        <div className="flex justify-center mb-3">
          <Instagram className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold mb-2 relative z-10">Instagram Account Sell</h2>
        <p className="text-blue-100 text-sm mb-6 relative z-10 text-center">ইনস্টাগ্রাম অ্যাকাউন্ট সেল করে টাকা<br/>ইনকাম করুন</p>
        
        <div className="grid grid-cols-3 gap-2 border-t border-blue-400/30 pt-4 relative z-10">
          <div>
            <p className="text-xs text-blue-200 font-medium mb-1 uppercase tracking-wider">Rate</p>
            <p className="text-xl font-bold">৳{adminSettings.rate}</p>
          </div>
          <div className="border-x border-blue-400/30">
            <p className="text-xs text-blue-200 font-medium mb-1 uppercase tracking-wider">Limit</p>
            <p className="text-xl font-bold">{adminSettings.limit}</p>
          </div>
          <div>
            <p className="text-xs text-blue-200 font-medium mb-1 uppercase tracking-wider">Submit</p>
            <p className="text-xl font-bold">{submittedCount}</p>
          </div>
        </div>
      </div>

      {/* Today's Password */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col items-center">
        <div className="bg-blue-50 p-3 rounded-full mb-3 text-blue-600">
          <Lock className="w-6 h-6" />
        </div>
        <p className="text-gray-500 text-sm mb-1 font-medium">Today's Password:</p>
        <p className="text-xl font-bold text-gray-900 mb-4 tracking-wide">{adminSettings.todaysPassword}</p>
        <button 
          onClick={handleCopy}
          className="flex items-center space-x-2 text-blue-700 bg-white border border-blue-200 px-6 py-2.5 rounded-full font-semibold hover:bg-blue-50 transition-colors shadow-sm"
        >
          <Copy className="w-4 h-4" />
          <span>Copy Password</span>
        </button>
      </div>

      {/* Submit Form */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 relative">
        <div className="text-center mb-6 mt-2">
          <h3 className="text-xl font-bold text-blue-800">Submit Your Account</h3>
          <p className="text-gray-500 text-sm mt-1 font-medium">সঠিক তথ্য দিয়ে নিচের ফর্মটি পূরণ করুন</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Instagram Username</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <AtSign className="h-5 w-5 text-blue-500" />
              </div>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter Username"
                className="w-full pl-11 pr-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:bg-white outline-none transition-all placeholder:text-gray-400 font-medium text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Account Password</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Lock className="h-5 w-5 text-blue-500" />
              </div>
              <input
                type="text"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter Password"
                className="w-full pl-11 pr-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:bg-white outline-none transition-all placeholder:text-gray-400 font-medium text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">2FA Key / Backup Codes</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Shield className="h-5 w-5 text-blue-500" />
              </div>
              <input
                type="text"
                required
                value={twoFaKey}
                onChange={(e) => setTwoFaKey(e.target.value)}
                placeholder="Enter 2FA Key"
                className="w-full pl-11 pr-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:bg-white outline-none transition-all placeholder:text-gray-400 font-medium text-sm"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white rounded-xl mt-6 py-3 font-bold text-base hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 transition-all flex justify-center items-center space-x-2 shadow-[0_4px_14px_0_rgba(37,99,235,0.39)]"
          >
             <Send className="w-5 h-5" />
             <span>SUBMIT INSTAGRAM ACCOUNT</span>
          </button>
        </form>
      </div>
    </div>
  );
}
