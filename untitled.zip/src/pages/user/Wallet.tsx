import { useState } from 'react';
import { useSettingsStore, PaymentMethod } from '../../store/useSettingsStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useTransactionStore } from '../../store/useTransactionStore';
import { Info, CheckCircle2 } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Wallet() {
  const { withdrawSetting } = useSettingsStore();
  const { profile, user, updateBalance } = useAuthStore();
  const { addTransaction } = useTransactionStore();
  const userId = user?.id || profile?.id || 'mock-user-id';
  const userBalance = profile?.balance || 0;

  const [selectedMethodId, setSelectedMethodId] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Find the selected method based on ID
  const selectedMethod: PaymentMethod | undefined = withdrawSetting.paymentMethods.find(m => m.id === selectedMethodId);

  const withdrawAmount = parseFloat(amount) || 0;
  const feePercentage = selectedMethod?.feePercentage || 0;
  const withdrawFee = (withdrawAmount * feePercentage) / 100;
  const totalDeduction = withdrawAmount + withdrawFee;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMethod) {
      toast.error("Please select a payment method.");
      return;
    }
    if (withdrawAmount < withdrawSetting.minWithdraw) {
      toast.error(`Minimum withdrawal amount is ৳${withdrawSetting.minWithdraw}`);
      return;
    }
    if (totalDeduction > userBalance) {
      toast.error("আপনার পর্যাপ্ত ব্যালেন্স নেই।");
      return;
    }
    if (!accountNumber) {
      toast.error("Please enter wallet / account number.");
      return;
    }
    
    if (selectedMethodId === 'bkash' || selectedMethodId === 'nagad') {
      const phoneRegex = /^01[3-9]\d{8}$/;
      if (!phoneRegex.test(accountNumber)) {
        toast.error("আপনি ফোন নাম্বার ভুল দিয়েছেন");
        return;
      }
    } else if (selectedMethodId === 'binance') {
      const bep20Regex = /^0x[a-fA-F0-9]{40}$/;
      if (!bep20Regex.test(accountNumber)) {
        toast.error("আপনি ভুল ওয়ালেট এড্রেস দিয়েছেন");
        return;
      }
    }

    setIsSubmitting(true);
    // Simulate API logic
    setTimeout(async () => {
      // Deduct balance
      await updateBalance(-totalDeduction);
      
      // Save history
      addTransaction({
        id: crypto.randomUUID(),
        userId,
        type: 'withdraw',
        amount: withdrawAmount,
        method: selectedMethod.name,
        accountNumber,
        status: 'pending',
        createdAt: new Date().toISOString()
      });

      toast.success("উত্তোলন সফলভাবে সাবমিট হয়েছে!");
      setAmount('');
      setAccountNumber('');
      setSelectedMethodId('');
      setIsSubmitting(false);
    }, 1000);
  };


  return (
    <div className="p-4 space-y-4 mb-24">
      {/* Notice Banner */}
      <div className="bg-blue-600 text-white rounded-lg p-3 flex overflow-hidden shadow-md items-center">
        <span className="font-bold mr-2 whitespace-nowrap">📢</span>
        <div className="flex-1 overflow-hidden relative flex items-center">
          <p className="animate-marquee whitespace-nowrap text-sm font-medium">
            {withdrawSetting.notice}
          </p>
        </div>
      </div>

      {/* Balance Card */}
      <div className="bg-gradient-to-br from-blue-700 to-blue-500 rounded-3xl p-6 text-white shadow-lg text-center relative overflow-hidden">
        <p className="text-blue-100 text-sm font-medium mb-1 uppercase tracking-widest">Available Balance</p>
        <p className="text-4xl font-bold mb-4">৳{userBalance.toFixed(2)}</p>
        
        <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-1.5 rounded-full text-sm">
          <Info className="w-4 h-4" />
          <span>Min. Withdraw: ৳{withdrawSetting.minWithdraw.toFixed(2)}</span>
        </div>
      </div>

      {/* Withdraw Form */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 relative">
        <div className="text-center mb-6 mt-2">
          <h3 className="text-2xl font-bold text-blue-800">Withdraw Funds</h3>
          <p className="text-gray-500 text-sm mt-1 font-medium">আপনার আয়ের টাকা নিরাপদে উত্তোলন করুন</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Payment Method Selector */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Select Payment Method</label>
            <div className="relative">
              <select
                value={selectedMethodId}
                onChange={(e) => setSelectedMethodId(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:bg-white outline-none transition-all appearance-none font-medium text-gray-800"
              >
                <option value="" disabled>Choose Method...</option>
                {withdrawSetting.paymentMethods.map(method => (
                  <option key={method.id} value={method.id}>
                    {method.name} ({method.feePercentage.toFixed(2)}% Fee)
                  </option>
                ))}
              </select>
            </div>

            {/* Selected Method Display */}
            {selectedMethod && (
              <div className="mt-4 border border-gray-200 rounded-xl p-4 flex items-center bg-gray-50/30">
                <div className="bg-white p-2 rounded-lg border border-gray-100 mr-4 shadow-sm h-12 w-12 flex items-center justify-center">
                  <img src={selectedMethod.logoUrl} alt={selectedMethod.name} className="w-8 h-8 object-contain" referrerPolicy="no-referrer" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase font-medium">Selected Method</p>
                  <p className="font-bold text-gray-900 text-lg">{selectedMethod.name}</p>
                </div>
              </div>
            )}
          </div>

          {/* Amount */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Withdraw Amount</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <span className="text-blue-500 font-bold">৳</span>
              </div>
              <input
                type="number"
                required
                min={withdrawSetting.minWithdraw}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="w-full pl-10 pr-4 py-3 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:bg-white outline-none transition-all placeholder:text-gray-400 font-medium"
              />
            </div>
          </div>

          {/* Calculation */}
          <div className="border border-dashed border-gray-300 rounded-xl p-4 bg-gray-50/50 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 font-medium">Withdraw Amount:</span>
              <span className="font-bold text-gray-800">৳{withdrawAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm border-b border-gray-200 pb-2">
              <span className="text-red-500 font-medium">Withdraw Fee ({feePercentage}%):</span>
              <span className="font-bold text-red-500">৳{withdrawFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between pt-1">
              <span className="text-blue-800 font-bold">Total Deduction:</span>
              <span className="font-bold text-blue-800 text-lg">৳{totalDeduction.toFixed(2)}</span>
            </div>
          </div>

          {/* Wallet Number */}
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              {selectedMethodId === 'binance' ? 'USDT BEP-20 Wallet Address' : 'Your Wallet / Account Number'}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                {selectedMethodId === 'binance' ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.172 13.828a4 4 0 015.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                )}
              </div>
              <input
                type="text"
                required
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder={selectedMethodId === 'binance' ? "📋 Enter your USDT BEP-20 wallet address" : "Ex: 017XXXXXXXX"}
                className="w-full pl-11 pr-4 py-3 bg-gray-50/50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:bg-white outline-none transition-all placeholder:text-gray-400 font-medium text-sm"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-blue-600 text-white rounded-full mt-6 py-4 font-bold text-base hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 transition-all flex justify-center items-center space-x-2 shadow-[0_4px_14px_0_rgba(37,99,235,0.39)] disabled:opacity-70"
          >
             <CheckCircle2 className="w-5 h-5" />
             <span className="uppercase">Confirm Withdrawal</span>
          </button>
        </form>
      </div>
    </div>
  );
}
