import { useState, useRef, useEffect } from 'react';
import { useSettingsStore } from '../../store/useSettingsStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Gift, Coins } from 'lucide-react';

export default function Spin() {
  const { spinSetting } = useSettingsStore();
  const { profile, updateBalance, updateLastSpinTime } = useAuthStore();
  const navigate = useNavigate();

  
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [resultModal, setResultModal] = useState<{ show: boolean; amount: number } | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  
  const wheelRef = useRef<HTMLDivElement>(null);

  // Rewards array from settings
  const rewards = spinSetting.rewards;
  const numSlices = rewards.length;
  const sliceAngle = 360 / numSlices;

  useEffect(() => {
    const lastSpinTime = profile?.lastSpinTime || 0;
    const timeSinceLastSpin = Date.now() - lastSpinTime;
    const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
    
    if (timeSinceLastSpin < TWENTY_FOUR_HOURS) {
      setTimeLeft(TWENTY_FOUR_HOURS - timeSinceLastSpin);
      const interval = setInterval(() => {
        const timeSince = Date.now() - lastSpinTime;
        if (timeSince >= TWENTY_FOUR_HOURS) {
          setTimeLeft(0);
          clearInterval(interval);
        } else {
          setTimeLeft(TWENTY_FOUR_HOURS - timeSince);
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [profile?.lastSpinTime]);

  const formatTime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((ms % (1000 * 60)) / 1000);
    return `${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`;
  };

  const initAudio = () => {
    if (!audioCtxRef.current) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtxRef.current = new AudioContextClass();
      }
    }
    if (audioCtxRef.current?.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const playTick = () => {
    try {
      const ctx = audioCtxRef.current;
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1000, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + 0.05);
      
      gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
      
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.05);
    } catch (e) {
      console.error(e);
    }
  };

  const playResultSound = (amount: number) => {
    try {
      const ctx = audioCtxRef.current;
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      if (amount > 0) {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        osc.frequency.setValueAtTime(1200, ctx.currentTime + 0.1);
        osc.frequency.setValueAtTime(1600, ctx.currentTime + 0.2);
        
        gainNode.gain.setValueAtTime(0, ctx.currentTime);
        gainNode.gain.linearRampToValueAtTime(2.0, ctx.currentTime + 0.05);
        gainNode.gain.setValueAtTime(2.0, ctx.currentTime + 0.3);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.0);
        
        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        osc.start();
        osc.stop(ctx.currentTime + 1.0);
      } else {
        osc.type = 'square';
        osc.frequency.setValueAtTime(300, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.4);
        
        gainNode.gain.setValueAtTime(0, ctx.currentTime);
        gainNode.gain.linearRampToValueAtTime(1.0, ctx.currentTime + 0.05);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);

        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSpin = () => {
    if (isSpinning || timeLeft > 0) return;
    
    initAudio();

    // Check if user has enough balance if cost is > 0
    if (spinSetting.costPerSpin > 0 && (profile?.balance || 0) < spinSetting.costPerSpin) {
      toast.error(`You need at least ৳${spinSetting.costPerSpin} to spin.`);
      return;
    }

    setIsSpinning(true);
    setLastWin(null);

    // Calculate total weight to random a winner
    const totalWeight = rewards.reduce((sum, reward) => sum + reward.probability, 0);
    let randomNum = Math.random() * totalWeight;

    let selectedIndex = 0;
    for (let i = 0; i < rewards.length; i++) {
        randomNum -= rewards[i].probability;
        if (randomNum <= 0) {
            selectedIndex = i;
            break;
        }
    }

    // Deduct cost and save
    if (spinSetting.costPerSpin > 0) {
      updateBalance(-spinSetting.costPerSpin);
    }

    // Determine the angle for the selected slice.
    // The pointer is usually at the top (0 deg or -90 deg depending on CSS setup).
    // Let's assume the top center points to the winning slice.
    const sliceCenterAngle = selectedIndex * sliceAngle + (sliceAngle / 2);
    // Add extra spins (e.g. 5 full rotations)
    const extraSpins = 360 * 5; 
    // Target rotation: land sliceCenter on the pointer (top = 0 deg, so we subtract sliceCenterAngle)
    const targetRotation = rotation + extraSpins + (360 - (sliceCenterAngle % 360));

    setRotation(targetRotation);

    const spinDuration = 5000;
    let tickCount = 0;
    // more ticks at start, fewer at end (ease out) could be complex, simple linear is ok
    const maxTicks = 40; 
    const tickInterval = setInterval(() => {
      playTick();
      tickCount++;
      if (tickCount >= maxTicks) {
        clearInterval(tickInterval);
      }
    }, spinDuration / maxTicks);

    setTimeout(() => {
        setIsSpinning(false);
        if (tickInterval) clearInterval(tickInterval);
        const winAmount = rewards[selectedIndex].amount;
        setLastWin(winAmount);
        
        // Add win to balance
        if (winAmount > 0) {
            updateBalance(winAmount);
        }
        updateLastSpinTime(Date.now());
        
        playResultSound(winAmount);
        setResultModal({ show: true, amount: winAmount });

    }, 5000); // 5s spin duration match CSS transition
  };

  return (
    <div className="p-4 flex flex-col items-center justify-center min-h-[calc(100vh-80px)] pb-6 overflow-hidden">
      <div className="text-center space-y-1 mb-4">
        <h1 className="text-3xl font-bold text-gray-900 flex justify-center items-center">
          <Gift className="w-7 h-7 text-blue-600 mr-2" />
          Daily Rewards
        </h1>
        <p className="text-gray-500 font-medium text-sm">Spin the wheel to win exciting cash prizes!</p>
      </div>

      <div className="h-12 flex items-center justify-center">
        {lastWin !== null && lastWin > 0 && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-6 py-2 rounded-full font-bold animate-bounce shadow-sm text-sm">
              🎉 You won ৳{lastWin}
          </div>
        )}
      </div>

      {/* Wheel Container */}
      <div className="relative w-72 h-72 my-6 sm:w-80 sm:h-80">
        {/* Pointer */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -mt-3 z-20">
          <div className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[20px] border-t-red-600 drop-shadow-md"></div>
        </div>

        {/* The Wheel */}
        <div 
          ref={wheelRef}
          className="w-full h-full rounded-full border-8 border-white shadow-xl relative overflow-hidden transition-transform"
          style={{
            transform: `rotate(${rotation}deg)`,
            transitionDuration: isSpinning ? '5s' : '0s',
            transitionTimingFunction: 'cubic-bezier(0.25, 1, 0.5, 1)', // ease-out effect
          }}
        >
          {/* Conic gradient for the wheel */}
          <div 
            className="absolute inset-0 z-0" 
            style={{
              background: `conic-gradient(${rewards.map((_, i) => `${i%2===0?'#3b82f6':'#60a5fa'} ${i*sliceAngle}deg ${(i+1)*sliceAngle}deg`).join(', ')})`
            }}
          />
          {/* Wheel Text */}
           {rewards.map((reward, index) => {
            const textAngle = index * sliceAngle + (sliceAngle / 2);
            return (
              <div 
                key={`text-${reward.id}`}
                className="absolute w-full h-full inset-0 z-10 flex justify-center items-start pt-3 sm:pt-5 text-white font-black text-xs sm:text-sm"
                style={{ transform: `rotate(${textAngle}deg)` }}
              >
                  ৳{reward.amount}
              </div>
            )
           })}
        </div>

        {/* Center dot */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-full shadow-md border-4 border-blue-200 z-20 flex items-center justify-center">
            <Coins className="w-4 h-4 sm:w-5 sm:h-5 text-blue-600" />
        </div>
      </div>

      <div className="w-full max-w-[280px] mt-4 flex flex-col items-center">
        {timeLeft > 0 ? (
          <button 
            disabled 
            className="w-full bg-gray-300 text-gray-600 rounded-xl py-4 font-bold text-lg shadow-sm cursor-not-allowed flex flex-col items-center"
          >
            <span>Next spin in</span>
            <span className="text-sm font-medium">{formatTime(timeLeft)}</span>
          </button>
        ) : (
          <button
            onClick={handleSpin}
            disabled={isSpinning}
            className="w-full bg-blue-600 text-white rounded-xl py-4 font-bold text-lg hover:bg-blue-700 transition-all shadow-lg active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSpinning ? 'Spinning...' : 'SPIN NOW'}
          </button>
        )}
      </div>

      {spinSetting.costPerSpin > 0 && typeof spinSetting.costPerSpin === 'number' && (
          <p className="text-gray-500 text-xs font-medium mt-3">Cost per spin: ৳{spinSetting.costPerSpin}</p>
      )}

      {resultModal?.show && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 transition-opacity" onClick={() => setResultModal(null)}>
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-2xl transform transition-all scale-100" onClick={e => e.stopPropagation()}>
            <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 ${resultModal.amount > 0 ? 'bg-green-100 text-green-500' : 'bg-gray-100 text-gray-500'}`}>
              {resultModal.amount > 0 ? <Gift className="w-10 h-10" /> : <Coins className="w-10 h-10" />}
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">
              {resultModal.amount > 0 ? 'Congratulations!' : 'Oops!'}
            </h3>
            <p className="text-gray-600 mb-6 font-medium">
              {resultModal.amount > 0 
                ? `You have won ৳${resultModal.amount} from the lucky spin!` 
                : 'Better luck next time! You won nothing this time.'}
            </p>
            <button
              onClick={() => {
                setResultModal(null);
              }}
              className="w-full bg-blue-600 text-white rounded-xl py-3 font-semibold hover:bg-blue-700 transition-colors"
            >
              Collect & Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
