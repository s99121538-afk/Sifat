import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Image as ImageIcon, Send, Upload } from 'lucide-react';
import { useJobStore } from '../../store/useJobStore';
import { useAuthStore } from '../../store/useAuthStore';
import toast from 'react-hot-toast';

export default function JobDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { jobs, submitJob } = useJobStore();
  const { user, profile } = useAuthStore();
  
  const job = jobs.find(j => j.id === id);
  
  const [proofText, setProofText] = useState('');
  const [proofImage, setProofImage] = useState<string>(''); // Can be URL or base64 for mockup
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!job) {
    return (
      <div className="p-4 flex flex-col items-center justify-center min-h-screen text-center">
        <p className="text-gray-500 font-medium mb-4">Job not found or no longer available.</p>
        <button onClick={() => navigate('/micro-jobs')} className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold">Go Back</button>
      </div>
    );
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app we would upload to Supabase Storage
      // Here we will just create a local object URL or mock it
      const objectUrl = URL.createObjectURL(file);
      setProofImage(objectUrl);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (job.requireTextProof && !proofText) {
      toast.error('Please provide text proof as required.');
      return;
    }
    if (job.requireScreenshot && !proofImage) {
      toast.error('Please provide a screenshot as required.');
      return;
    }
    if (!job.requireTextProof && !job.requireScreenshot && !proofText && !proofImage) {
       toast.error('Please submit some form of proof.');
       return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      submitJob({
        id: crypto.randomUUID(),
        jobId: job.id,
        userId: user?.id || profile?.id || 'mock-user-id',
        jobTitle: job.title,
        jobPrice: job.price,
        proofText,
        proofImage,
        status: 'PENDING',
        createdAt: new Date().toISOString()
      });
      setIsSubmitting(false);
      toast.success('Job proof submitted successfully!');
      navigate('/job-history');
    }, 1000);
  };

  return (
    <div className="p-4 mb-24 max-w-lg mx-auto bg-gray-50 min-h-screen">
      <div className="flex items-center space-x-3 mb-6 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
        <button onClick={() => navigate(-1)} className="p-2 bg-gray-50 rounded-full hover:bg-gray-100 transition-colors">
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">Job Details</h1>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-blue-50 mb-6">
        <div className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-bold mb-4">
          {job.category}
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">{job.title}</h2>
        <div className="flex items-center space-x-4 mb-6 text-sm font-medium">
          <span className="text-blue-600 bg-blue-50 px-3 py-1 rounded-lg">Pay: ৳{job.price.toFixed(2)}</span>
          <span className="text-gray-500">{job.totalSpots - job.filledSpots} spots left</span>
        </div>
        
        <div className="bg-[#f8fbff] p-4 rounded-2xl border border-blue-50">
          <h3 className="font-bold text-blue-900 mb-2">Description / Instructions</h3>
          <p className="text-gray-700 whitespace-pre-wrap text-sm leading-relaxed mb-4">
            {job.description}
          </p>
          
          {job.instructionImage && (
            <div className="mt-4">
              <h4 className="font-bold text-blue-900 text-sm mb-2">Example / Reference</h4>
              <img src={job.instructionImage} alt="Instruction" className="rounded-xl w-full object-cover border border-blue-100" />
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-blue-50">
        <h3 className="font-bold text-gray-800 mb-4 text-lg">Submit Proof</h3>
        <form onSubmit={handleSubmit} className="space-y-5">
           {job.requireTextProof && (
             <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Text Proof (Link / Username / Info) <span className="text-red-500">*</span></label>
              <textarea
                value={proofText}
                onChange={(e) => setProofText(e.target.value)}
                placeholder="Provide requested details or links..."
                rows={4}
                className="w-full px-4 py-3 bg-[#f5f8ff] border border-transparent rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all font-medium text-gray-800 resize-none"
              />
            </div>
           )}

          {job.requireScreenshot && (
            <div>
               <label className="block text-sm font-bold text-gray-700 mb-2">Screenshot Proof <span className="text-red-500">*</span></label>
               {proofImage ? (
                 <div className="relative rounded-2xl overflow-hidden border border-gray-200">
                    <img src={proofImage} alt="Proof" className="w-full object-cover max-h-48" />
                    <button 
                      type="button"
                      onClick={() => setProofImage('')}
                      className="absolute top-2 right-2 bg-red-500 text-white text-xs px-3 py-1 rounded-full font-bold shadow-sm hover:bg-red-600"
                    >
                      Remove
                    </button>
                 </div>
               ) : (
                  <div className="relative">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <div className="w-full bg-[#f5f8ff] border-2 border-dashed border-blue-200 rounded-2xl py-8 flex flex-col items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors">
                      <Upload className="w-8 h-8 mb-2" />
                      <span className="font-medium">Upload Screenshot</span>
                    </div>
                  </div>
               )}
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-blue-700 to-blue-500 text-white rounded-full py-4 font-bold text-base hover:from-blue-800 hover:to-blue-600 transition-all flex justify-center items-center space-x-2 shadow-lg disabled:opacity-70 mt-4"
          >
            {isSubmitting ? (
              <span className="animate-pulse">Submitting...</span>
            ) : (
              <>
                <span>SUBMIT WORK</span>
                <Send className="w-5 h-5" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
