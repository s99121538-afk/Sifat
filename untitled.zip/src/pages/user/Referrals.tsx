import { useAuthStore } from '../../store/useAuthStore';
import { Users, Copy, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';

export default function Referrals() {
  const { user, profile } = useAuthStore();

  const handleCopyCode = () => {
    const code = profile?.referralCode || ('REF-' + (user?.id?.substring(0,8).toUpperCase() || 'NEWX01'));
    navigator.clipboard.writeText(code);
    toast.success("Referral code copied!");
  };

  return (
    <div className="p-4 space-y-6 max-w-lg mx-auto">
      <div className="flex items-center space-x-3 mb-6 relative">
        <Link to="/dashboard" className="absolute left-0 p-2 bg-white rounded-full shadow-sm hover:bg-gray-50 transition-colors">
           <ArrowLeft className="w-5 h-5 text-gray-700" />
        </Link>
        <h2 className="text-2xl font-bold text-gray-800 text-center w-full">Referrals</h2>
      </div>

      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-100 p-6 rounded-3xl shadow-sm">
        <div className="flex flex-col items-center mb-6">
           <div className="bg-blue-100 p-4 rounded-full mb-3 text-blue-600">
             <Users className="w-8 h-8" />
           </div>
           <h3 className="font-bold text-gray-800 text-lg">Your Referral Code</h3>
           <p className="text-sm text-gray-500 text-center mt-1">Share this code with your friends and earn bonus when they join and complete tasks!</p>
        </div>
        
        <div className="flex bg-white rounded-2xl overflow-hidden shadow-sm mb-6 border border-gray-100 p-1">
          <div className="flex-1 px-4 py-3 font-mono font-bold text-blue-700 text-center tracking-wider text-lg">
            {profile?.referralCode || ('REF-' + (user?.id?.substring(0,8).toUpperCase() || 'NEWX01'))}
          </div>
          <button onClick={handleCopyCode} className="bg-blue-600 text-white px-5 rounded-xl hover:bg-blue-700 transition flex items-center shadow-sm">
            <Copy className="w-5 h-5 mr-1.5" /> Copy
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
           <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 text-center flex flex-col items-center">
             <div className="text-gray-500 text-xs font-bold mb-2 uppercase tracking-wider">Total Referrals</div>
             <div className="text-3xl font-black text-gray-800">{profile?.totalReferrals || 0}</div>
           </div>
           <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 text-center flex flex-col items-center">
             <div className="text-gray-500 text-xs font-bold mb-2 uppercase tracking-wider">Total Earnings</div>
             <div className="text-3xl font-black text-green-600">
               ৳ {profile?.referralEarnings?.toFixed(2) || '0.00'}
             </div>
           </div>
        </div>
      </div>
    </div>
  );
}
