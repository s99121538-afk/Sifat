import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { History, Search, Star, User, ChevronDown } from 'lucide-react';
import { useJobStore } from '../../store/useJobStore';
import { useAuthStore } from '../../store/useAuthStore';

const CATEGORIES = [
  'All Categories',
  'Facebook',
  'Youtube',
  'Telegram',
  'Sign Up',
  'Review',
  'Mobile Application',
  'Linkedin',
  'Ads Click',
  'Tik-tok',
  'Instagram'
];

export default function MicroJobs() {
  const navigate = useNavigate();
  const { jobs, submissions } = useJobStore();
  const { user, profile } = useAuthStore();
  const userId = user?.id || profile?.id || 'mock-user-id';
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [showCategories, setShowCategories] = useState(false);

  // Exclude jobs that the user has already submitted (they go to history)
  const submittedJobIds = new Set(submissions.filter(s => s.userId === userId).map(s => s.jobId));
  
  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      // 1. Must not have been submitted by this user
      if (submittedJobIds.has(job.id)) return false;
      
      // 2. Must match search term
      if (searchTerm && !job.title.toLowerCase().includes(searchTerm.toLowerCase())) return false;
      
      // 3. Must match category
      if (selectedCategory !== 'All Categories' && job.category !== selectedCategory) return false;
      
      return true;
    });
  }, [jobs, submittedJobIds, searchTerm, selectedCategory]);

  return (
    <div className="p-4 mb-24 max-w-lg mx-auto bg-[#eef4ff] min-h-screen">
      {/* Header Placeholder (Optional if covered by layout) */}
      
      <button 
        onClick={() => navigate('/job-history')}
        className="w-full bg-white border border-blue-500 text-blue-800 font-bold py-3.5 rounded-2xl flex items-center justify-center space-x-2 shadow-sm hover:bg-blue-50 transition-colors mb-6"
      >
        <History className="w-5 h-5 text-blue-600" />
        <span>View Work History</span>
      </button>

      {/* Filters Container */}
      <div className="bg-white p-4 rounded-3xl shadow-sm mb-6 border border-gray-100">
        <div className="flex bg-[#f5f8ff] rounded-xl overflow-hidden mb-4 border border-transparent focus-within:border-blue-200 transition-colors">
          <input 
            type="text" 
            placeholder="Search tasks or jobs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 bg-transparent px-4 py-3 outline-none text-gray-700 placeholder-gray-400 font-medium"
          />
          <button className="bg-blue-600 px-6 flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
            <Search className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="relative">
          <button 
            onClick={() => setShowCategories(!showCategories)}
            className="w-full flex items-center justify-between bg-white border border-blue-200 px-4 py-3.5 rounded-xl text-gray-800 font-medium hover:bg-gray-50 transition-colors"
          >
            <span>{selectedCategory}</span>
            <ChevronDown className={`w-5 h-5 text-gray-500 transition-transform ${showCategories ? 'rotate-180' : ''}`} />
          </button>

          {showCategories && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-100 rounded-2xl shadow-xl z-20 max-h-64 overflow-y-auto">
              {CATEGORIES.map(category => (
                <button
                  key={category}
                  onClick={() => {
                    setSelectedCategory(category);
                    setShowCategories(false);
                  }}
                  className="w-full flex items-center px-4 py-3.5 hover:bg-[#f5f8ff] border-b border-gray-50 last:border-0 transition-colors"
                >
                  <span className="flex-1 text-left font-medium text-gray-700 text-lg">{category}</span>
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${selectedCategory === category ? 'border-blue-800' : 'border-gray-400'}`}>
                    {selectedCategory === category && <div className="w-3 h-3 bg-blue-800 rounded-full" />}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Jobs List */}
      <div className="space-y-4">
        {filteredJobs.length === 0 ? (
          <div className="text-center py-10 bg-white rounded-3xl shadow-sm">
            <p className="text-gray-500 font-medium">No tasks available matching your criteria.</p>
          </div>
        ) : (
          filteredJobs.map(job => {
            const spotsRemaining = job.totalSpots - job.filledSpots;
            const progressPercent = (job.filledSpots / job.totalSpots) * 100;
            
            return (
              <div 
                key={job.id} 
                onClick={() => navigate(`/job/${job.id}`)}
                className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100 flex items-center space-x-4 cursor-pointer hover:shadow-md transition-shadow relative overflow-hidden"
              >
                <div className="bg-blue-600 min-w-[3.5rem] w-14 h-14 rounded-2xl flex items-center justify-center shadow-inner flex-shrink-0">
                  <Star className="w-6 h-6 text-white fill-current" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-blue-900 text-[15px] mb-2 truncate">{job.title}</h3>
                  
                  <div className="flex items-center space-x-3">
                    <div className="bg-[#eef4ff] text-blue-800 px-3 py-1 rounded-lg flex flex-col items-center min-w-[3rem]">
                      <span className="font-bold">{job.price.toFixed(2)}</span>
                      <span className="text-xs font-semibold">৳</span>
                    </div>
                    
                    <div className="flex flex-col flex-1 pl-1">
                       <div className="flex items-center justify-between w-full mb-1">
                          <div className="flex items-center text-gray-500 text-xs font-medium">
                            <User className="w-3.5 h-3.5 mr-1" />
                            <span>{spotsRemaining} spots left</span>
                          </div>
                          <span className="text-xs font-bold text-gray-800">{job.filledSpots} / {job.totalSpots}</span>
                       </div>
                       <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
                         <div className="bg-blue-600 h-full rounded-full" style={{ width: `${progressPercent}%` }} />
                       </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
