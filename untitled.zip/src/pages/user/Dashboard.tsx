import { Link } from 'react-router-dom';
import { useAuthStore } from '../../store/useAuthStore';
import { ArrowUpRight, ArrowDownRight, Wallet, Mail, Facebook, Instagram, Phone, Gift, Users, Briefcase, CheckSquare, Send, Youtube } from 'lucide-react';

export default function UserDashboard() {
  const { profile } = useAuthStore();

  const services = [
    { name: 'Gmail', icon: Mail, color: 'bg-red-500', path: '/services/gmail' },
    { name: 'Facebook', icon: Facebook, color: 'bg-blue-600', path: '/services/facebook' },
    { name: 'Instagram', icon: Instagram, color: 'bg-pink-600', path: '/services/instagram' },
    { name: 'WhatsApp', icon: Phone, color: 'bg-green-500', path: '/services/whatsapp' },
  ];

  return (
    <div className="p-4 space-y-6">
      {/* Notice Marquee */}
      <div className="bg-blue-50 border border-blue-200 text-blue-800 rounded-lg p-2 flex overflow-hidden">
        <span className="font-bold mr-2 whitespace-nowrap">📢 Notice:</span>
        <div className="flex-1 overflow-hidden relative flex items-center">
          <p className="animate-marquee whitespace-nowrap">
            Welcome to Account Hub! Sell your accounts securely and get fast payments.
          </p>
        </div>
      </div>

      {/* Balance Card */}
      <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <span className="text-blue-100 font-medium">Total Balance</span>
          <Wallet className="w-6 h-6 text-blue-200" />
        </div>
        <h2 className="text-4xl font-bold mb-6">৳ {(profile?.balance ?? 0).toFixed(2)}</h2>
        
        <div className="grid grid-cols-2 gap-4">
          <Link to="/deposit" className="flex items-center justify-center space-x-2 bg-white/20 hover:bg-white/30 transition-colors py-3 rounded-xl font-semibold backdrop-blur-sm">
            <ArrowDownRight className="w-5 h-5" />
            <span>Deposit</span>
          </Link>
          <Link to="/wallet" className="flex items-center justify-center space-x-2 bg-white text-blue-600 hover:bg-gray-50 transition-colors py-3 rounded-xl font-semibold shadow-sm">
            <ArrowUpRight className="w-5 h-5" />
            <span>Withdraw</span>
          </Link>
        </div>
      </div>

      {/* Social Links */}
      <div className="grid grid-cols-2 gap-4">
        <a 
          href="https://t.me/admin_username" 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow flex items-center justify-center space-x-3"
        >
          <div className="bg-blue-500 w-8 h-8 rounded-full flex items-center justify-center text-white">
            <Send className="w-4 h-4 -ml-0.5" />
          </div>
          <span className="font-bold text-gray-800">Telegram</span>
        </a>
        <a 
          href="https://youtube.com/@channel" 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow flex items-center justify-center space-x-3"
        >
          <div className="bg-red-600 w-8 h-8 rounded-full flex items-center justify-center text-white">
            <Youtube className="w-4 h-4" />
          </div>
          <span className="font-bold text-gray-800">YouTube</span>
        </a>
      </div>

      {/* Action Grid */}
      <div>
        <h3 className="text-lg font-bold text-gray-800 mb-4">Sell Accounts</h3>
        <div className="grid grid-cols-2 gap-4">
          {services.map((service) => (
            <Link key={service.name} to={service.path} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow flex flex-col items-center justify-center h-28">
              <div className={`${service.color} w-12 h-12 rounded-full flex items-center justify-center text-white mb-3 shadow-inner`}>
                <service.icon className="w-6 h-6" />
              </div>
              <span className="font-semibold text-gray-700">{service.name}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* Jobs & Tasks */}
      <div>
        <h3 className="text-lg font-bold text-gray-800 mb-4">Earn Money</h3>
        <div className="grid grid-cols-2 gap-4">
          <Link to="/micro-jobs" className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow flex flex-col items-center justify-center h-28">
             <div className="bg-indigo-500 w-12 h-12 rounded-full flex items-center justify-center text-white mb-3 shadow-inner">
               <Briefcase className="w-6 h-6" />
             </div>
             <span className="font-semibold text-gray-700">Micro Jobs</span>
          </Link>
          <Link to="/daily-tasks" className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow flex flex-col items-center justify-center h-28">
             <div className="bg-teal-500 w-12 h-12 rounded-full flex items-center justify-center text-white mb-3 shadow-inner">
               <CheckSquare className="w-6 h-6" />
             </div>
             <span className="font-semibold text-gray-700">Daily Tasks</span>
          </Link>
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-lg font-bold text-gray-800 mb-4">More Options</h3>
        <div className="grid grid-cols-2 gap-4">
          <Link to="/spin" className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center space-x-3 hover:bg-gray-50 transition-colors">
            <Gift className="w-6 h-6 text-orange-500" />
            <span className="font-medium text-gray-700">Daily Bonus</span>
          </Link>
          <Link to="/referrals" className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center space-x-3 hover:bg-gray-50 transition-colors">
            <Users className="w-6 h-6 text-purple-500" />
            <span className="font-medium text-gray-700">Referrals</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
