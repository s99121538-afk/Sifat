import { useState } from 'react';
import { useSettingsStore, DepositMethod } from '../../store/useSettingsStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useTransactionStore } from '../../store/useTransactionStore';
import { Copy, Info, Send } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Deposit() {
  const { depositSetting } = useSettingsStore();
  const { profile, user } = useAuthStore();
  const { addTransaction } = useTransactionStore();
  const userId = user?.id || profile?.id || 'mock-user-id';

  const [selectedMethodId, setSelectedMethodId] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [senderAccount, setSenderAccount] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Find the selected method based on ID
  const selectedMethod: DepositMethod | undefined = depositSetting.depositMethods.find(m => m.id === selectedMethodId);

  const depositAmount = parseFloat(amount) || 0;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("নম্বর কপি করা হয়েছে!");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMethod) {
      toast.error("Please select a payment method.");
      return;
    }
    if (depositAmount < depositSetting.minDeposit) {
      toast.error(`Minimum deposit amount is ৳${depositSetting.minDeposit}`);
      return;
    }
    if (!senderAccount) {
      toast.error("Please enter the number you sent money from.");
      return;
    }

    if (selectedMethodId === 'bkash' || selectedMethodId === 'nagad') {
      const phoneRegex = /^01[3-9]\d{8}$/;
      if (!phoneRegex.test(senderAccount)) {
        toast.error("আপনি ফোন নাম্বার ভুল দিয়েছেন");
        return;
      }
    } else if (selectedMethodId === 'binance') {
      const bep20Regex = /^0x[a-fA-F0-9]{40}$/;
      if (!bep20Regex.test(senderAccount)) {
        toast.error("আপনি ভুল ওয়ালেট এড্রেস দিয়েছেন");
        return;
      }
    }
    
    setIsSubmitting(true);
    // Simulate API logic
    setTimeout(() => {
      // Save history
      addTransaction({
        id: crypto.randomUUID(),
        userId,
        type: 'deposit',
        amount: depositAmount,
        method: selectedMethod.name,
        accountNumber: senderAccount,
        status: 'pending',
        createdAt: new Date().toISOString()
      });

      toast.success("ডিপোজিট সফলভাবে সাবমিট হয়েছে!");
      setAmount('');
      setSenderAccount('');
      setSelectedMethodId('');
      setIsSubmitting(false);
    }, 1000);
  };


  return (
    <div className="p-4 space-y-4 mb-24">
      {/* Target Action Banner */}
      <div className="bg-blue-600 text-white rounded-lg p-3 flex justify-center items-center shadow-md">
        <span className="font-bold mr-2 text-xl">📢</span>
        <p className="text-sm font-medium">
          দেওয়া নাম্বারটি কপি করে সেন্ড মানি করুন
        </p>
      </div>

      {/* Notice Card */}
      <div className="bg-blue-600 rounded-2xl p-6 text-white shadow-lg text-center relative overflow-hidden">
        <div className="flex justify-center items-center mb-2">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
            </svg>
           <h2 className="text-2xl font-bold">Deposit Balance</h2>
        </div>
        <p className="text-blue-100 text-sm font-medium">
          {depositSetting.notice}
        </p>
      </div>

      {/* Deposit Form */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 relative">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Payment Method Selector */}
          <div>
            <label className="block text-sm font-bold text-blue-900 mb-2">পেমেন্ট মেথড সিলেক্ট করুন</label>
            <div className="relative">
              <select
                value={selectedMethodId}
                onChange={(e) => setSelectedMethodId(e.target.value)}
                className="w-full px-4 py-3 bg-white border border-blue-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all appearance-none font-medium text-gray-800"
              >
                <option value="" disabled>মেথড বেছে নিন</option>
                {depositSetting.depositMethods.map(method => (
                  <option key={method.id} value={method.id}>
                    {method.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Selected Method Display & Copy */}
            {selectedMethod && (
              <div className="mt-4 border border-blue-100 rounded-xl p-4 flex flex-col sm:flex-row items-center sm:justify-between bg-blue-50/50">
                <div className="flex items-center w-full sm:w-auto">
                  <div className="bg-white p-2 text-center rounded-lg border border-blue-100 mr-4 shadow-sm h-12 w-12 flex items-center justify-center">
                    <img src={selectedMethod.logoUrl} alt={selectedMethod.name} className="w-8 h-8 object-contain" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <p className="text-xs text-blue-500 uppercase font-bold text-left">{selectedMethod.name} Number</p>
                    <p className="font-bold text-gray-900 text-lg">{selectedMethod.accountNumber}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(selectedMethod.accountNumber)}
                  className="mt-3 sm:mt-0 w-full sm:w-auto flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors font-medium text-sm"
                >
                  <Copy className="w-4 h-4" />
                  <span>Copy</span>
                </button>
              </div>
            )}
          </div>

          {/* Amount */}
          <div>
            <label className="block text-sm font-bold text-blue-900 mb-2">আপনি কত টাকা অ্যাড করতে চান?</label>
            <div className="flex rounded-xl overflow-hidden border border-blue-100 shadow-sm focus-within:ring-2 focus-within:ring-blue-500">
              <div className="bg-blue-50 px-4 flex items-center justify-center font-bold text-blue-600 text-lg border-r border-blue-100">
                ৳
              </div>
              <input
                type="number"
                required
                min={depositSetting.minDeposit}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-4 py-3 bg-gray-50/50 focus:bg-white outline-none transition-all placeholder:text-gray-400 font-medium"
              />
            </div>
            {amount && depositAmount < depositSetting.minDeposit && (
              <p className="text-red-500 text-xs mt-1 font-medium">Minimum deposit is ৳{depositSetting.minDeposit}</p>
            )}
          </div>

          {/* Calculation */}
          <div className="border border-dashed border-blue-200 rounded-xl p-4 bg-blue-50/30 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 font-bold">মূল অ্যামাউন্ট:</span>
              <span className="font-bold text-gray-800">৳{depositAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm border-b border-blue-100 pb-3">
              <span className="text-gray-600 font-bold">পেমেন্ট ফি (0%):</span>
              <span className="font-bold text-red-500">+ ৳0.00</span>
            </div>
            <div className="flex justify-between pt-1">
              <span className="text-blue-900 font-bold text-lg">আপনাকে পাঠাতে হবে:</span>
              <span className="font-bold text-blue-900 text-xl">৳{depositAmount.toFixed(2)}</span>
            </div>
            <div className="mt-4 bg-green-50 border border-green-200 text-green-700 rounded-lg p-3 flex items-center justify-center">
               <Info className="w-5 h-5 mr-2 text-green-600" />
               <span className="font-bold text-sm">আপনার ব্যালেন্সে ৳{depositAmount.toFixed(2)} যোগ হবে।</span>
            </div>
          </div>

          {/* Sender Wallet Number */}
          <div>
            <label className="block text-sm font-bold text-blue-900 mb-2">
              {selectedMethodId === 'binance' ? 'যে ওয়ালেট থেকে ডলার পাঠিয়েছেন (USDT BEP-20)' : 'যে নম্বর থেকে টাকা পাঠিয়েছেন'}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                {selectedMethodId === 'binance' ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.172 13.828a4 4 0 015.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                )}
              </div>
              <input
                type="text"
                required
                value={senderAccount}
                onChange={(e) => setSenderAccount(e.target.value)}
                placeholder={selectedMethodId === 'binance' ? "📋 Enter your USDT BEP-20 wallet address" : "e.g. 01XXXXXXXXX"}
                className="w-full pl-11 pr-4 py-3 bg-gray-50/50 border border-blue-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 focus:bg-white outline-none transition-all placeholder:text-gray-400 font-medium text-sm"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-blue-600 text-white rounded-xl mt-6 py-4 font-bold text-base hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 transition-all flex justify-center items-center space-x-2 shadow-md disabled:opacity-70"
          >
             <span>Submit Deposit Request</span>
             <Send className="w-5 h-5 ml-2" />
          </button>
        </form>
      </div>
    </div>
  );
}
