import { useState } from 'react';
import { useStoreItemStore, StoreItem } from '../../store/useStoreItemStore';
import { format } from 'date-fns';
import { Plus, Edit, Trash2, Package, Eye } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminStore() {
  const { items, purchases, addItem, updateItem, deleteItem } = useStoreItemStore();
  const [activeTab, setActiveTab] = useState<'items' | 'purchases'>('items');

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<StoreItem | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: 0,
    imageUrl: '',
    content: ''
  });

  const openModal = (item?: StoreItem) => {
    if (item) {
      setEditingItem(item);
      setFormData({
        title: item.title,
        description: item.description,
        price: item.price,
        imageUrl: item.imageUrl || '',
        content: item.content
      });
    } else {
      setEditingItem(null);
      setFormData({
        title: '',
        description: '',
        price: 0,
        imageUrl: '',
        content: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingItem) {
      updateItem(editingItem.id, { ...formData });
      toast.success('Item updated successfully');
    } else {
      addItem({
        id: crypto.randomUUID(),
        ...formData,
        createdAt: new Date().toISOString()
      });
      toast.success('Item added successfully');
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      deleteItem(id);
      toast.success('Item deleted');
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Store Management</h1>
        <button 
          onClick={() => openModal()}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 font-medium hover:bg-indigo-700"
        >
          <Plus className="w-5 h-5" />
          <span>Add New Item</span>
        </button>
      </div>

      <div className="flex space-x-4 border-b border-gray-200 mb-6">
        <button
          onClick={() => setActiveTab('items')}
          className={`py-3 px-6 font-semibold border-b-2 transition-colors ${activeTab === 'items' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
        >
          Manage Items ({items.length})
        </button>
        <button
          onClick={() => setActiveTab('purchases')}
          className={`py-3 px-6 font-semibold border-b-2 transition-colors ${activeTab === 'purchases' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
        >
          Purchase History ({purchases.length})
        </button>
      </div>

      {activeTab === 'items' && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {items.map(item => (
            <div key={item.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden flex flex-col">
              {item.imageUrl ? (
                <img src={item.imageUrl} alt={item.title} className="w-full h-40 object-cover" />
              ) : (
                <div className="bg-gray-50 w-full h-40 flex items-center justify-center text-gray-400">
                  <Package className="w-10 h-10" />
                </div>
              )}
              <div className="p-5 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-gray-900 text-lg">{item.title}</h3>
                  <span className="font-bold text-indigo-600">৳{item.price.toFixed(2)}</span>
                </div>
                <p className="text-gray-500 text-sm mb-4 line-clamp-2">{item.description}</p>
                <div className="bg-indigo-50 p-3 rounded-xl mb-4 flex-1">
                  <span className="text-xs font-bold text-indigo-800 block mb-1">Secret Content:</span>
                  <p className="text-xs text-indigo-900 whitespace-pre-wrap line-clamp-3">{item.content}</p>
                </div>
                <div className="flex space-x-2 mt-auto">
                  <button onClick={() => openModal(item)} className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200 flex justify-center items-center">
                    <Edit className="w-4 h-4 mr-1.5" /> Edit
                  </button>
                  <button onClick={() => handleDelete(item.id)} className="flex-1 bg-red-50 text-red-600 py-2 rounded-lg font-medium hover:bg-red-100 flex justify-center items-center">
                    <Trash2 className="w-4 h-4 mr-1.5" /> Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
          {items.length === 0 && (
            <div className="col-span-full text-center py-12 bg-white rounded-2xl border border-gray-100 text-gray-500">
              No items created yet. Add one above.
            </div>
          )}
        </div>
      )}

      {activeTab === 'purchases' && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-gray-600 text-sm">
              <tr>
                <th className="p-4 font-semibold">User ID</th>
                <th className="p-4 font-semibold">Item</th>
                <th className="p-4 font-semibold">Price</th>
                <th className="p-4 font-semibold">Purchased At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {purchases.sort((a,b) => (b.purchasedAt ? new Date(b.purchasedAt).getTime() : 0) - (a.purchasedAt ? new Date(a.purchasedAt).getTime() : 0)).map(p => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="p-4 font-medium text-gray-800"><span className="bg-gray-100 px-2 py-1 rounded text-xs">{p.userId.substring(0,8)}...</span></td>
                  <td className="p-4 font-bold text-indigo-900">{p.itemTitle}</td>
                  <td className="p-4 font-semibold text-gray-700">৳{p.price.toFixed(2)}</td>
                  <td className="p-4 text-gray-500 text-sm">{p.purchasedAt ? format(new Date(p.purchasedAt), 'dd MMM yyyy, HH:mm') : 'Unknown'}</td>
                </tr>
              ))}
              {purchases.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-gray-500">No purchases found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-6">{editingItem ? 'Edit Item' : 'Create New Item'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Item Title</label>
                <input required type="text" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description (Public)</label>
                <textarea required rows={3} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 resize-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Price (৳)</label>
                  <input required type="number" step="0.01" min="0" value={formData.price || ''} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Image URL (Optional)</label>
                  <input type="text" value={formData.imageUrl} placeholder="https://..." onChange={e => setFormData({...formData, imageUrl: e.target.value})} className="w-full p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                <label className="flex items-center text-sm font-bold text-indigo-900 mb-2">
                  <Eye className="w-4 h-4 mr-1.5" /> Secret Content (Revealed after purchase)
                </label>
                <textarea required rows={4} placeholder="Links, credentials, secret notes..." value={formData.content} onChange={e => setFormData({...formData, content: e.target.value})} className="w-full p-3 border border-indigo-200 rounded-xl focus:ring-2 focus:ring-indigo-500 resize-none" />
              </div>
              
              <div className="flex space-x-3 pt-4">
                <button type="submit" className="flex-1 bg-indigo-600 text-white font-bold py-3.5 rounded-xl hover:bg-indigo-700">Save Item</button>
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 bg-gray-100 text-gray-700 font-bold py-3.5 rounded-xl hover:bg-gray-200">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
