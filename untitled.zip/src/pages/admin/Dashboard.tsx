import { Users, DollarSign, Activity, AlertCircle } from 'lucide-react';

export default function AdminDashboard() {
  const stats = [
    { label: 'Total Users', value: '1,248', icon: Users, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Pending Deposits', value: '৳ 45,000', icon: DollarSign, color: 'text-amber-600', bg: 'bg-amber-100' },
    { label: 'Pending Withdrawals', value: '৳ 12,500', icon: Activity, color: 'text-emerald-600', bg: 'bg-emerald-100' },
    { label: 'Pending Accounts', value: '34', icon: AlertCircle, color: 'text-purple-600', bg: 'bg-purple-100' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-500">System overview and quick statistics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className={`${stat.bg} p-3 rounded-lg`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </div>
            <h3 className="text-gray-500 text-sm font-medium">{stat.label}</h3>
            <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">Recent Activity</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-2 border-b">
               <div>
                 <p className="font-medium text-gray-800">User @rakib deposited 1000 BDT</p>
                 <p className="text-sm text-gray-500">2 mins ago</p>
               </div>
               <button className="text-sm text-blue-600 hover:underline">Review</button>
            </div>
            <div className="flex items-center justify-between py-2 border-b">
               <div>
                 <p className="font-medium text-gray-800">User @sakib submitted a Gmail</p>
                 <p className="text-sm text-gray-500">15 mins ago</p>
               </div>
               <button className="text-sm text-blue-600 hover:underline">Review</button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">Quick Links</h2>
          <div className="grid grid-cols-2 gap-4">
            <button className="p-3 border rounded-lg hover:bg-gray-50 font-medium text-gray-700">Manage Notices</button>
            <button className="p-3 border rounded-lg hover:bg-gray-50 font-medium text-gray-700">App Settings</button>
            <button className="p-3 border rounded-lg hover:bg-gray-50 font-medium text-gray-700">Approve Jobs</button>
            <button className="p-3 border rounded-lg hover:bg-gray-50 font-medium text-gray-700">Maintenance Mode</button>
          </div>
        </div>
      </div>
    </div>
  );
}
