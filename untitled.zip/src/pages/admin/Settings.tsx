import { useState } from 'react';
import { useSettingsStore, DepositMethod } from '../../store/useSettingsStore';
import toast from 'react-hot-toast';

export default function AdminSettings() {
  const { depositSetting, updateDepositSetting, spinSetting, updateSpinSetting, referralSetting, updateReferralSetting } = useSettingsStore();

  const [methods, setMethods] = useState<DepositMethod[]>(depositSetting.depositMethods);
  const [notice, setNotice] = useState<string>(depositSetting.notice);
  const [minDeposit, setMinDeposit] = useState<number>(depositSetting.minDeposit);
  const [spinRewards, setSpinRewards] = useState(spinSetting.rewards);
  const [referralRewardAmount, setReferralRewardAmount] = useState<number>(referralSetting.rewardAmount);
  const [isReferralEnabled, setIsReferralEnabled] = useState<boolean>(referralSetting.isEnabled);

  const handleInputChange = (id: string, field: keyof DepositMethod, value: string) => {
    setMethods(methods.map(m => m.id === id ? { ...m, [field]: value } : m));
  };

  const handleSpinChange = (id: string, field: keyof typeof spinRewards[0], value: number) => {
    setSpinRewards(spinRewards.map(r => r.id === id ? { ...r, [field]: value } : r));
  };

  const handleSave = () => {
    updateDepositSetting({ depositMethods: methods, notice, minDeposit });
    updateSpinSetting({ rewards: spinRewards });
    updateReferralSetting({ isEnabled: isReferralEnabled, rewardAmount: referralRewardAmount });
    toast.success("Settings updated successfully!");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">App Settings</h1>
        <p className="text-gray-500">Manage application configurations.</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-6">
        <div>
          <h2 className="text-lg font-bold text-gray-800 mb-4">Deposit Settings</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Notice</label>
              <textarea
                value={notice}
                onChange={(e) => setNotice(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                rows={3}
                placeholder="Enter deposit notice..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Deposit Amount</label>
              <input
                type="number"
                value={minDeposit}
                onChange={(e) => setMinDeposit(Number(e.target.value))}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="0.00"
              />
            </div>
          </div>
        </div>

        <hr className="border-gray-100" />
        <h2 className="text-lg font-bold text-gray-800 mb-4">Deposit Account Numbers</h2>
        <div className="space-y-6">
          {methods.map((method) => (
            <div key={method.id} className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center bg-gray-50 p-4 rounded-lg border border-gray-200">
              <div className="flex items-center space-x-4">
                <img src={method.logoUrl} alt={method.name} className="w-10 h-10 object-contain rounded" />
                <span className="font-semibold text-gray-800">{method.name}</span>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {method.id === 'binance' ? 'Wallet Address' : 'Account Number'}
                </label>
                <input
                  type="text"
                  value={method.accountNumber}
                  onChange={(e) => handleInputChange(method.id, 'accountNumber', e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder={`Enter ${method.name} number`}
                />
              </div>
            </div>
          ))}
        </div>
        <hr className="border-gray-100" />
        <h2 className="text-lg font-bold text-gray-800 mb-4">Spin & Win Rewards / Odds</h2>
        <p className="text-sm text-gray-500 mb-4">Set the amount and probability weight for each spin reward slot. The higher the probability number, the more likely the user will land on it. E.g. To make 10Tk 1 in 1000 chances, you can set it to 1, and the others to total 999.</p>
        <div className="space-y-4">
          {spinRewards.map((reward, index) => (
            <div key={reward.id} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center bg-gray-50 p-4 rounded-lg border border-gray-200">
              <div className="font-semibold text-gray-800">
                Slot {index + 1}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Reward Amount (Tk)</label>
                <input
                  type="number"
                  step="0.1"
                  value={reward.amount}
                  onChange={(e) => handleSpinChange(reward.id, 'amount', Number(e.target.value))}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Probability Weight</label>
                <input
                  type="number"
                  value={reward.probability}
                  onChange={(e) => handleSpinChange(reward.id, 'probability', Number(e.target.value))}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>
          ))}
        </div>

        <hr className="border-gray-100" />
        <h2 className="text-lg font-bold text-gray-800 mb-4">Referral Settings</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-gray-50 p-4 rounded-lg border border-gray-200">
           <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Referral Reward Amount (Tk)</label>
              <input
                type="number"
                step="0.5"
                value={referralRewardAmount}
                onChange={(e) => setReferralRewardAmount(Number(e.target.value))}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              />
           </div>
           <div className="flex items-center space-x-3 pt-6">
              <input 
                 type="checkbox" 
                 id="enableRef"
                 checked={isReferralEnabled}
                 onChange={(e) => setIsReferralEnabled(e.target.checked)}
                 className="w-5 h-5"
              />
              <label htmlFor="enableRef" className="font-semibold text-gray-700 cursor-pointer">Enable Referral System</label>
           </div>
        </div>

        <div className="mt-8 pt-4 border-t border-gray-100 flex justify-end">
          <button
            onClick={handleSave}
            className="bg-blue-600 text-white px-8 py-3 rounded-lg font-bold hover:bg-blue-700 transition"
          >
            Save All Settings
          </button>
        </div>
      </div>
    </div>
  );
}
