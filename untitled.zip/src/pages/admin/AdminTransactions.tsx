import { useState } from 'react';
import { useTransactionStore } from '../../store/useTransactionStore';
import { Check, X, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { format } from 'date-fns';
import toast from 'react-hot-toast';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';

export default function AdminTransactions() {
  const { transactions, updateTransactionStatus } = useTransactionStore();
  const [activeTab, setActiveTab] = useState<'pending' | 'history'>('pending');

  const pendingTransactions = transactions.filter(t => t.status === 'pending').sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const historyTransactions = transactions.filter(t => t.status !== 'pending').sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handleApprove = async (id: string, userId: string, type: string, amount: number) => {
    updateTransactionStatus(id, 'success');
    
    if (type === 'deposit') {
      try {
        if (isSupabaseConfigured) {
          // Add amount to user's balance
          const { data: profile } = await supabase.from('profiles').select('balance').eq('id', userId).single();
          if (profile) {
            await supabase.from('profiles').update({ balance: (profile.balance || 0) + amount }).eq('id', userId);
          }
        }
        toast.success(`Deposit approved. Balance updated.`);
      } catch(e) {
        toast.error('Failed to update balance');
      }
    } else {
      toast.success('Withdrawal approved.');
    }
  };

  const handleReject = async (id: string, userId: string, type: string, amount: number) => {
    updateTransactionStatus(id, 'rejected');
    
    if (type === 'withdraw') {
      try {
        if (isSupabaseConfigured) {
          // Refund the amount + fee (though currently we just have amount. Assuming we refund amount, proper app might refund amount+fee)
          // Since fee is tricky, let's just refund the requested amount
          const { data: profile } = await supabase.from('profiles').select('balance').eq('id', userId).single();
          if (profile) {
            await supabase.from('profiles').update({ balance: (profile.balance || 0) + amount }).eq('id', userId);
          }
        }
        toast.success(`Withdrawal rejected. Balance refunded.`);
      } catch(e) {
        toast.error('Failed to refund balance');
      }
    } else {
      toast.success('Deposit rejected.');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Transactions</h1>
        <p className="text-gray-500">Manage user deposits and withdrawals</p>
      </div>

      <div className="flex space-x-2 bg-white p-1 rounded-lg w-fit shadow-sm border">
        <button
          onClick={() => setActiveTab('pending')}
          className={`px-4 py-2 rounded-md font-medium text-sm transition-colors ${activeTab === 'pending' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
        >
          Pending Requests ({pendingTransactions.length})
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-4 py-2 rounded-md font-medium text-sm transition-colors ${activeTab === 'history' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
        >
          History
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">User ID</th>
                <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Method</th>
                <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Details</th>
                <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                <th className="p-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status/Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {(activeTab === 'pending' ? pendingTransactions : historyTransactions).map(t => (
                <tr key={t.id} className="hover:bg-gray-50">
                  <td className="p-4">
                     <span className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-xs font-bold ${t.type === 'deposit' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                        {t.type === 'deposit' ? <ArrowDownRight className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                        <span className="uppercase">{t.type}</span>
                     </span>
                  </td>
                  <td className="p-4 font-medium text-gray-800"><span className="bg-gray-100 px-2 py-1 rounded text-xs">{t.userId.substring(0,8)}...</span></td>
                  <td className="p-4 font-bold text-gray-900">৳{t.amount.toFixed(2)}</td>
                  <td className="p-4 font-semibold text-gray-700">{t.method}</td>
                  <td className="p-4">
                    <p className="text-sm font-medium text-gray-800">A/C: {t.accountNumber}</p>
                  </td>
                  <td className="p-4 text-gray-500 text-sm">{format(new Date(t.createdAt), 'dd MMM yyyy, HH:mm')}</td>
                  <td className="p-4">
                     {activeTab === 'pending' ? (
                        <div className="flex space-x-2">
                          <button onClick={() => handleApprove(t.id, t.userId, t.type, t.amount)} className="p-2 text-green-600 hover:bg-green-50 rounded-lg" title="Approve">
                            <Check className="w-5 h-5" />
                          </button>
                          <button onClick={() => handleReject(t.id, t.userId, t.type, t.amount)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg" title="Reject">
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                     ) : (
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                           t.status === 'success' ? 'bg-green-100 text-green-700' : 
                           t.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                           {t.status.toUpperCase()}
                        </span>
                     )}
                  </td>
                </tr>
              ))}
              {(activeTab === 'pending' ? pendingTransactions : historyTransactions).length === 0 && (
                <tr>
                   <td colSpan={7} className="p-8 text-center text-gray-500">
                      No {activeTab} transactions found.
                   </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
