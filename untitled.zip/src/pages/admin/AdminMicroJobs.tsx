import { useState } from 'react';
import { useJobStore, MicroJob, JobStatus } from '../../store/useJobStore';
import { format } from 'date-fns';
import { CheckCircle, XCircle, Trash2, Plus, Edit, Eye, User } from 'lucide-react';
import toast from 'react-hot-toast';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useSettingsStore } from '../../store/useSettingsStore';
import { handleReferralBonus } from '../../lib/referral';

export default function AdminMicroJobs() {
  const { jobs, submissions, addJob, updateJob, deleteJob, updateSubmissionStatus } = useJobStore();
  
  const [activeTab, setActiveTab] = useState<'jobs' | 'submissions'>('submissions');
  
  // Job Form Modal
  const [isJobModalOpen, setIsJobModalOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<MicroJob | null>(null);
  const [jobForm, setJobForm] = useState({
    title: '',
    category: 'Facebook',
    price: 0,
    totalSpots: 0,
    description: '',
    instructionImage: '',
    requireTextProof: true,
    requireScreenshot: true,
    iconType: 'default'
  });

  const CATEGORIES = ['Facebook', 'Youtube', 'Telegram', 'Sign Up', 'Review', 'Mobile Application', 'Linkedin', 'Ads Click', 'Tik-tok', 'Instagram', 'Gmail', 'WhatsApp'];

  const openJobModal = (job?: MicroJob) => {
    if (job) {
      setEditingJob(job);
      setJobForm({
        title: job.title,
        category: job.category,
        price: job.price,
        totalSpots: job.totalSpots,
        description: job.description,
        instructionImage: job.instructionImage || '',
        requireTextProof: job.requireTextProof,
        requireScreenshot: job.requireScreenshot,
        iconType: job.iconType
      });
    } else {
      setEditingJob(null);
      setJobForm({
        title: '',
        category: 'Facebook',
        price: 1,
        totalSpots: 100,
        description: '',
        instructionImage: '',
        requireTextProof: true,
        requireScreenshot: true,
        iconType: 'facebook'
      });
    }
    setIsJobModalOpen(true);
  };

  const handleJobSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingJob) {
      updateJob(editingJob.id, { ...jobForm });
      toast.success('Job updated successfully');
    } else {
      addJob({
        id: crypto.randomUUID(),
        ...jobForm,
        filledSpots: 0,
        createdAt: new Date().toISOString()
      });
      toast.success('Job created successfully');
    }
    setIsJobModalOpen(false);
  };

  // Submission Management
  const [rejectReason, setRejectReason] = useState('');
  const [rejectModalOpen, setRejectModalOpen] = useState(false);
  const [selectedSubmissionId, setSelectedSubmissionId] = useState('');
  const { referralSetting } = useSettingsStore();

  const handleApprove = async (id: string, userId: string, amount: number) => {
    if (window.confirm('Are you sure you want to approve this submission?')) {
      updateSubmissionStatus(id, 'SUCCESS');
      
      // Update balance in Supabase
      if (isSupabaseConfigured) {
        try {
          const { data: profile } = await supabase.from('profiles').select('balance').eq('id', userId).single();
          if (profile) {
            await supabase.from('profiles').update({ balance: (profile.balance || 0) + amount }).eq('id', userId);
          }
          await handleReferralBonus(userId, referralSetting);
        } catch(e) {
          console.error(e);
        }
      }

      toast.success('Approved successfully');
    }
  };

  const openRejectModal = (id: string) => {
    setSelectedSubmissionId(id);
    setRejectReason('');
    setRejectModalOpen(true);
  };

  const handleReject = () => {
    if (!rejectReason.trim()) {
      toast.error('Please enter a rejection reason.');
      return;
    }
    updateSubmissionStatus(selectedSubmissionId, 'REJECTED', rejectReason);
    setRejectModalOpen(false);
    toast.success('Submission rejected');
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Micro Jobs Management</h1>
        <button 
          onClick={() => openJobModal()}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 font-medium hover:bg-blue-700"
        >
          <Plus className="w-5 h-5" />
          <span>Add New Job</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex space-x-4 border-b border-gray-200 mb-6">
        <button
          onClick={() => setActiveTab('submissions')}
          className={`py-3 px-6 font-semibold border-b-2 transition-colors ${activeTab === 'submissions' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
        >
          Submissions ({submissions.length})
        </button>
        <button
          onClick={() => setActiveTab('jobs')}
          className={`py-3 px-6 font-semibold border-b-2 transition-colors ${activeTab === 'jobs' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
        >
          Manage Jobs ({jobs.length})
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'jobs' && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-gray-600 text-sm">
              <tr>
                <th className="p-4 font-semibold">Title</th>
                <th className="p-4 font-semibold">Category</th>
                <th className="p-4 font-semibold">Price</th>
                <th className="p-4 font-semibold">Spots</th>
                <th className="p-4 font-semibold">Created At</th>
                <th className="p-4 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {jobs.map(job => (
                <tr key={job.id} className="hover:bg-gray-50">
                  <td className="p-4 font-medium text-gray-800">{job.title}</td>
                  <td className="p-4">
                    <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-bold">{job.category}</span>
                  </td>
                  <td className="p-4">৳{job.price.toFixed(2)}</td>
                  <td className="p-4">{job.filledSpots} / {job.totalSpots}</td>
                  <td className="p-4 text-gray-500 text-sm">{job.createdAt ? format(new Date(job.createdAt), 'dd MMM yyyy, HH:mm') : 'Unknown'}</td>
                  <td className="p-4">
                    <div className="flex space-x-2">
                       <button onClick={() => openJobModal(job)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg">
                         <Edit className="w-5 h-5" />
                       </button>
                       <button onClick={() => {
                         if (window.confirm('Delete this job?')) deleteJob(job.id);
                       }} className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                         <Trash2 className="w-5 h-5" />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
              {jobs.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-gray-500">No jobs found. Create one above.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'submissions' && (
        <div className="grid gap-4">
          {submissions.sort((a,b) => (b.createdAt ? new Date(b.createdAt).getTime() : 0) - (a.createdAt ? new Date(a.createdAt).getTime() : 0)).map(sub => (
            <div key={sub.id} className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-6">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                   <h3 className="font-bold text-gray-900 text-lg">{sub.jobTitle}</h3>
                   <span className="bg-gray-100 px-3 py-1 rounded-full text-xs font-bold text-gray-600">ID: {sub.userId.substring(0,8)}...</span>
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center"><User className="w-4 h-4 mr-1" /> User Submitter</div>
                  <div>Cost: <span className="font-bold text-blue-700">৳{sub.jobPrice}</span></div>
                  <div>Date: {sub.createdAt ? format(new Date(sub.createdAt), 'dd MMM yyyy, HH:mm') : 'Unknown'}</div>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-xl mb-4 border border-gray-200">
                  <h4 className="font-semibold text-gray-700 mb-2">Proof Details:</h4>
                  <p className="text-gray-800 whitespace-pre-wrap">{sub.proofText}</p>
                  
                  {sub.proofImage && (
                    <div className="mt-4">
                      <a href={sub.proofImage} target="_blank" rel="noopener noreferrer" className="text-blue-600 font-medium hover:underline flex items-center">
                        <Eye className="w-4 h-4 mr-1" /> View Uploaded Screenshot
                      </a>
                    </div>
                  )}
                </div>
                
                {sub.status === 'REJECTED' && (
                  <div className="bg-red-50 text-red-700 p-3 rounded-lg border border-red-100 mb-4">
                    <span className="font-bold">Rejection Reason: </span>
                    {sub.rejectReason}
                  </div>
                )}
              </div>
              
              <div className="md:w-48 flex flex-col justify-center space-y-3 border-t md:border-t-0 md:border-l border-gray-100 pt-4 md:pt-0 md:pl-6">
                <div>
                  <span className="text-xs text-gray-500 font-medium block mb-1">Status</span>
                  <div className={`px-3 py-1.5 rounded-lg text-sm font-bold text-center ${
                    sub.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                    sub.status === 'SUCCESS' ? 'bg-green-100 text-green-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {sub.status}
                  </div>
                </div>
                
                {sub.status === 'PENDING' && (
                  <>
                    <button 
                      onClick={() => handleApprove(sub.id, sub.userId, sub.jobPrice)}
                      className="w-full bg-green-600 text-white py-2 rounded-lg font-medium hover:bg-green-700 flex justify-center items-center"
                    >
                      <CheckCircle className="w-4 h-4 mr-1.5" /> Approve
                    </button>
                    <button 
                      onClick={() => openRejectModal(sub.id)}
                      className="w-full bg-red-600 text-white py-2 rounded-lg font-medium hover:bg-red-700 flex justify-center items-center"
                    >
                      <XCircle className="w-4 h-4 mr-1.5" /> Reject
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
          {submissions.length === 0 && (
             <div className="text-center py-12 bg-white rounded-2xl border border-gray-100 text-gray-500">
               No submissions yet.
             </div>
          )}
        </div>
      )}

      {/* Modals */}
      {isJobModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg shadow-xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">{editingJob ? 'Edit Job' : 'Create New Job'}</h2>
            <form onSubmit={handleJobSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Job Title</label>
                <input required type="text" value={jobForm.title} onChange={e => setJobForm({...jobForm, title: e.target.value})} className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                  <select value={jobForm.category} onChange={e => setJobForm({...jobForm, category: e.target.value})} className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Price (৳)</label>
                  <input required type="number" step="0.01" min="0" value={jobForm.price || ''} onChange={e => setJobForm({...jobForm, price: parseFloat(e.target.value)})} className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Total Spots</label>
                <input required type="number" min="1" value={jobForm.totalSpots || ''} onChange={e => setJobForm({...jobForm, totalSpots: parseInt(e.target.value)})} className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description / Instructions</label>
                <textarea required rows={4} value={jobForm.description} onChange={e => setJobForm({...jobForm, description: e.target.value})} className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 resize-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Instruction Image URL (Optional)</label>
                <input type="text" value={jobForm.instructionImage} placeholder="e.g. https://example.com/image.png" onChange={e => setJobForm({...jobForm, instructionImage: e.target.value})} className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" />
              </div>
              <div className="flex gap-4">
                <label className="flex items-center space-x-2">
                  <input type="checkbox" checked={jobForm.requireTextProof} onChange={e => setJobForm({...jobForm, requireTextProof: e.target.checked})} className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4" />
                  <span className="text-sm font-medium text-gray-700">Require Text Proof</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="checkbox" checked={jobForm.requireScreenshot} onChange={e => setJobForm({...jobForm, requireScreenshot: e.target.checked})} className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4" />
                  <span className="text-sm font-medium text-gray-700">Require Screenshot</span>
                </label>
              </div>
              <div className="flex space-x-3 pt-4">
                <button type="submit" className="flex-1 bg-blue-600 text-white font-bold py-2.5 rounded-lg hover:bg-blue-700">Save Job</button>
                <button type="button" onClick={() => setIsJobModalOpen(false)} className="flex-1 bg-gray-100 text-gray-700 font-bold py-2.5 rounded-lg hover:bg-gray-200">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {rejectModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
             <h3 className="text-lg font-bold text-gray-900 mb-4">Reject Submission</h3>
             <label className="block text-sm font-medium text-gray-700 mb-2">Provide a reason for rejection:</label>
             <textarea 
               value={rejectReason}
               onChange={(e) => setRejectReason(e.target.value)}
               rows={3} 
               className="w-full p-3 border border-gray-300 rounded-xl mb-4 focus:ring-2 focus:ring-blue-500"
               placeholder="e.g. Screenshot missing..."
             />
             <div className="flex space-x-3">
               <button onClick={handleReject} className="flex-1 bg-red-600 text-white py-2 rounded-lg font-bold hover:bg-red-700">Reject</button>
               <button onClick={() => setRejectModalOpen(false)} className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg font-bold hover:bg-gray-200">Cancel</button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
