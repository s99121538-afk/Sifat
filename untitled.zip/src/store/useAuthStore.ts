import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

interface UserState {
  user: any | null;
  profile: any | null;
  isLoading: boolean;
  isAdmin: boolean;
  setUser: (user: any, profile?: any) => void;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
  updateBalance: (amount: number) => Promise<void>;
  updateLastSpinTime: (time: number) => Promise<void>;
  updateReferralStats: (amount: number) => Promise<void>;
}

export const useAuthStore = create<UserState>()(
  persist(
    (set) => ({
      user: null,
      profile: null,
      isLoading: true, // Only true initially for Supabase auth checking
      isAdmin: false,
      setUser: (user, profile) => set({ user, profile, isAdmin: profile?.role === 'admin' }),
      updateLastSpinTime: async (time: number) => {
        set((state) => {
          if (isSupabaseConfigured && state.user) {
             supabase.from('profiles').update({ last_spin_time: new Date(time).toISOString() }).eq('id', state.user.id).then();
          }
          return {
            profile: { ...(state.profile || {}), lastSpinTime: time }
          };
        });
      },
      updateBalance: async (amount: number) => {
        set((state) => {
          const currentBalance = state.profile?.balance || 0;
          const newBalance = currentBalance + amount;
          
          if (isSupabaseConfigured && state.user) {
            supabase.from('profiles').update({ balance: newBalance }).eq('id', state.user.id).then();
          }

          return {
            profile: { ...(state.profile || {}), balance: newBalance }
          };
        });
      },
      updateReferralStats: async (amount: number) => {
        set((state) => {
          const currentEarnings = state.profile?.referralEarnings || 0;
          const currentCount = state.profile?.totalReferrals || 0;
          
          if (isSupabaseConfigured && state.user) {
             supabase.from('profiles').update({ 
               referralEarnings: currentEarnings + amount,
               totalReferrals: currentCount + 1
             }).eq('id', state.user.id).then();
          }
          return {
            profile: { ...(state.profile || {}), referralEarnings: currentEarnings + amount, totalReferrals: currentCount + 1 }
          };
        });
      },
      logout: async () => {
        if (isSupabaseConfigured) {
          await supabase.auth.signOut();
        }
        set({ user: null, profile: null, isAdmin: false });
      },
      checkAuth: async () => {
        if (!isSupabaseConfigured) {
          // In mock mode, don't clear the persisted user!
          set({ isLoading: false });
          return;
        }

        try {
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user) {
            const { data: profile } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', session.user.id)
              .single();
            
            set({ 
              user: session.user, 
              profile, 
              isAdmin: profile?.role === 'admin',
              isLoading: false 
            });
          } else {
            set({ user: null, profile: null, isLoading: false });
          }
        } catch (error) {
          console.error('Auth Check Error:', error);
          set({ user: null, profile: null, isLoading: false });
        }
      }
    }),
    {
      name: 'auth-storage', // name of the item in the storage (must be unique)
      partialize: (state) => ({ user: state.user, profile: state.profile, isAdmin: state.isAdmin }),
    }
  )
);
