import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface DailyTask {
  id: string;
  title: string;
  category: string;
  price: number;
  totalSpots: number;
  filledSpots: number;
  description: string;
  instructionImage?: string;
  requireTextProof: boolean;
  requireScreenshot: boolean;
  iconType: string;
  createdAt: string;
}

export type TaskStatus = 'PENDING' | 'SUCCESS' | 'REJECTED';

export interface TaskSubmission {
  id: string;
  taskId: string;
  userId: string;
  proofText: string;
  proofImage?: string;
  status: TaskStatus;
  rejectReason?: string;
  createdAt: string;
  taskTitle?: string;
  taskPrice?: number;
}

interface DailyTaskState {
  tasks: DailyTask[];
  submissions: TaskSubmission[];
  addTask: (task: DailyTask) => void;
  updateTask: (id: string, data: Partial<DailyTask>) => void;
  deleteTask: (id: string) => void;
  submitTask: (submission: TaskSubmission) => void;
  submitSocialAccount: (submission: TaskSubmission) => void;
  updateSubmissionStatus: (id: string, status: TaskStatus, rejectReason?: string) => void;
}

const initialTasks: DailyTask[] = [
  {
    id: '1',
    title: 'Daily Check-in & Share',
    category: 'Facebook',
    price: 1.00,
    totalSpots: 1000,
    filledSpots: 291,
    description: 'Check in daily and share our latest post on your timeline.',
    requireTextProof: true,
    requireScreenshot: true,
    iconType: 'facebook',
    createdAt: new Date().toISOString()
  }
];

export const useDailyTaskStore = create<DailyTaskState>()(
  persist(
    (set) => ({
      tasks: initialTasks,
      submissions: [],
      addTask: (task) => set((state) => ({ tasks: [task, ...state.tasks] })),
      updateTask: (id, data) => set((state) => ({
        tasks: state.tasks.map(t => t.id === id ? { ...t, ...data } : t)
      })),
      deleteTask: (id) => set((state) => ({
        tasks: state.tasks.filter(t => t.id !== id)
      })),
      submitTask: (submission) => set((state) => ({
        submissions: [submission, ...state.submissions],
        tasks: state.tasks.map(t => t.id === submission.taskId ? { ...t, filledSpots: t.filledSpots + 1 } : t)
      })),
      submitSocialAccount: (submission) => set((state) => ({
        submissions: [submission, ...state.submissions]
      })),
      updateSubmissionStatus: (id, status, rejectReason) => set((state) => ({
        submissions: state.submissions.map(s => 
          s.id === id ? { ...s, status, rejectReason: rejectReason || s.rejectReason } : s
        )
      }))
    }),
    {
      name: 'daily-task-storage'
    }
  )
);
