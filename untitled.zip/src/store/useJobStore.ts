import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface MicroJob {
  id: string;
  title: string;
  category: string;
  price: number;
  totalSpots: number;
  filledSpots: number;
  description: string;
  instructionImage?: string;
  requireTextProof: boolean;
  requireScreenshot: boolean;
  iconType: string;
  createdAt: string;
}

export type JobStatus = 'PENDING' | 'SUCCESS' | 'REJECTED';

export interface JobSubmission {
  id: string;
  jobId: string;
  userId: string;
  proofText: string;
  proofImage?: string;
  status: JobStatus;
  rejectReason?: string;
  createdAt: string;
  jobTitle?: string;
  jobPrice?: number;
}

interface JobState {
  jobs: MicroJob[];
  submissions: JobSubmission[];
  addJob: (job: MicroJob) => void;
  updateJob: (id: string, data: Partial<MicroJob>) => void;
  deleteJob: (id: string) => void;
  submitJob: (submission: JobSubmission) => void;
  updateSubmissionStatus: (id: string, status: JobStatus, rejectReason?: string) => void;
}

const initialJobs: MicroJob[] = [
  {
    id: '1',
    title: 'Online Income Group Join And Post',
    category: 'Facebook',
    price: 3.00,
    totalSpots: 300,
    filledSpots: 291,
    description: 'Join the group and create a post. Take a screenshot as proof.',
    requireTextProof: true,
    requireScreenshot: true,
    iconType: 'facebook',
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    title: 'Channel Join And Share',
    category: 'Youtube',
    price: 1.00,
    totalSpots: 500,
    filledSpots: 274,
    description: 'Subscribe to the channel and share the latest video.',
    requireTextProof: true,
    requireScreenshot: false,
    iconType: 'youtube',
    createdAt: new Date().toISOString()
  }
];

export const useJobStore = create<JobState>()(
  persist(
    (set) => ({
      jobs: initialJobs,
      submissions: [],
      addJob: (job) => set((state) => ({ jobs: [job, ...state.jobs] })),
      updateJob: (id, data) => set((state) => ({
        jobs: state.jobs.map(j => j.id === id ? { ...j, ...data } : j)
      })),
      deleteJob: (id) => set((state) => ({
        jobs: state.jobs.filter(j => j.id !== id)
      })),
      submitJob: (submission) => set((state) => ({
        submissions: [submission, ...state.submissions],
        jobs: state.jobs.map(j => j.id === submission.jobId ? { ...j, filledSpots: j.filledSpots + 1 } : j)
      })),
      updateSubmissionStatus: (id, status, rejectReason) => set((state) => ({
        submissions: state.submissions.map(s => 
          s.id === id ? { ...s, status, rejectReason: rejectReason || s.rejectReason } : s
        )
      }))
    }),
    {
      name: 'job-storage'
    }
  )
);
