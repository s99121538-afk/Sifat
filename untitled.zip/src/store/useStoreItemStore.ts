import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface StoreItem {
  id: string;
  title: string;
  description: string;
  price: number;
  imageUrl?: string;
  content: string; // The secret info revealed after purchase
  createdAt: string;
}

export interface Purchase {
  id: string;
  userId: string;
  itemId: string;
  itemTitle: string;
  price: number;
  content: string;
  purchasedAt: string;
}

interface StoreItemState {
  items: StoreItem[];
  purchases: Purchase[];
  addItem: (item: StoreItem) => void;
  updateItem: (id: string, data: Partial<StoreItem>) => void;
  deleteItem: (id: string) => void;
  addPurchase: (purchase: Purchase) => void;
}

const initialItems: StoreItem[] = [
  {
    id: '1',
    title: 'Premium Themes Pack',
    description: 'Get access to 10 premium themes for your website.',
    price: 50.00,
    content: 'Here is your download link: https://example.com/download/themes-pack-v1.zip',
    createdAt: new Date().toISOString()
  }
];

export const useStoreItemStore = create<StoreItemState>()(
  persist(
    (set) => ({
      items: initialItems,
      purchases: [],
      addItem: (item) => set((state) => ({ items: [item, ...state.items] })),
      updateItem: (id, data) => set((state) => ({
        items: state.items.map(i => i.id === id ? { ...i, ...data } : i)
      })),
      deleteItem: (id) => set((state) => ({
        items: state.items.filter(i => i.id !== id)
      })),
      addPurchase: (purchase) => set((state) => ({
        purchases: [purchase, ...state.purchases]
      }))
    }),
    {
      name: 'store-item-management'
    }
  )
);
