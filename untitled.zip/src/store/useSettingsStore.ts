import { create } from 'zustand';

export interface PaymentMethod {
  id: string;
  name: string;
  feePercentage: number;
  logoUrl: string;
}

export interface DepositMethod {
  id: string;
  name: string;
  accountNumber: string;
  logoUrl: string;
}

interface ServiceSettings {
  notice: string;
  tutorialLink: string;
  rate: string;
  limit: number;
  todaysPassword?: string;
  reportTime: string;
}

interface WithdrawSettings {
  notice: string;
  minWithdraw: number;
  paymentMethods: PaymentMethod[];
}

interface DepositSettings {
  notice: string;
  minDeposit: number;
  depositMethods: DepositMethod[];
}

interface SpinReward {
  id: string;
  amount: number;
  probability: number; // weight or chance (e.g. 1 means 1 in 1000 if total is 1000)
}

interface SpinSettings {
  rewards: SpinReward[];
  costPerSpin: number;
}

interface ReferralSettings {
  isEnabled: boolean;
  rewardAmount: number;
}

interface SettingsState {
  gmailSetting: ServiceSettings;
  facebookSetting: ServiceSettings;
  instagramSetting: ServiceSettings;
  whatsappSetting: ServiceSettings;
  withdrawSetting: WithdrawSettings;
  depositSetting: DepositSettings;
  spinSetting: SpinSettings;
  referralSetting: ReferralSettings;
  userBalance: number; // Placeholder for UI testing
  contactSettings: {
    whatsapp: string;
    telegram: string;
    youtube: string;
  };
  updateGmailSetting: (newSetting: Partial<ServiceSettings>) => void;
  updateFacebookSetting: (newSetting: Partial<ServiceSettings>) => void;
  updateInstagramSetting: (newSetting: Partial<ServiceSettings>) => void;
  updateWhatsappSetting: (newSetting: Partial<ServiceSettings>) => void;
  updateWithdrawSetting: (newSetting: Partial<WithdrawSettings>) => void;
  updateDepositSetting: (newSetting: Partial<DepositSettings>) => void;
  updateSpinSetting: (newSetting: Partial<SpinSettings>) => void;
  updateReferralSetting: (newSetting: Partial<ReferralSettings>) => void;
  updateContactSettings: (newSettings: Partial<SettingsState['contactSettings']>) => void;
  updateUserBalance: (newBalance: number) => void;
}

// In a real app this would sync with a backend (like Supabase).
// For now, we set initial static values that the admin panel can update.
export const useSettingsStore = create<SettingsState>((set) => ({
  userBalance: 0.00, // Starting balance
  gmailSetting: {
    notice: "জিমেইল বিক্রির নিয়মাবলী মেনে কাজ করুন। ভুল পাসওয়ার্ড দিলে একাউন্ট বাতিল হবে।",
    tutorialLink: "https://youtube.com",
    rate: "15.00",
    limit: 1000,
    todaysPassword: "HrEarningPoint@#bd",
    reportTime: "রিপোর্ট টাইম: ২০-৩০ ঘণ্টা"
  },
  facebookSetting: {
    notice: "ফেসবুক বিক্রির নিয়মাবলী মেনে কাজ করুন। ভুল পাসওয়ার্ড দিলে একাউন্ট বাতিল হবে।",
    tutorialLink: "https://youtube.com",
    rate: "4.00",
    limit: 500,
    todaysPassword: "HREARNINGPOINT@#12",
    reportTime: "12-24 hours"
  },
  instagramSetting: {
    notice: "ইনস্টাগ্রাম বিক্রির নিয়মাবলী মেনে কাজ করুন।",
    tutorialLink: "https://youtube.com",
    rate: "3.50",
    limit: 1000,
    todaysPassword: "HREARNINGPOINT12",
    reportTime: "6-12 hours"
  },
  whatsappSetting: {
    notice: "WhatsApp বিক্রির নিয়মাবলী মেনে কাজ করুন।",
    tutorialLink: "https://youtube.com",
    rate: "15.00",
    limit: 1000,
    todaysPassword: "s991215378@gmail.com\nvkadbfidg@gmail.com",
    reportTime: "রিপোর্ট টাইম: ২০-৩০ ঘণ্টা"
  },
  withdrawSetting: {
    notice: "সবকিছু সঠিক থাকলে ১২ ঘন্টার মধ্যে আপনার টাকা পেয়ে যাবেন।",
    minWithdraw: 50.00,
    paymentMethods: [
      { id: 'bkash', name: 'Bkash', feePercentage: 5.00, logoUrl: 'https://seeklogo.com/images/B/bkash-logo-FBB258B90F-seeklogo.com.png' },
      { id: 'nagad', name: 'Nagad', feePercentage: 5.00, logoUrl: 'https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png' },
      { id: 'binance', name: 'Binance', feePercentage: 5.00, logoUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%23181A20'/%3E%3Cg transform='translate(25,25) scale(2.0833)' fill='%23F0B90B'%3E%3Cpath d='M16.624 13.92l2.717 2.716-7.353 7.353-7.353-7.353 2.717-2.716 4.636 4.66 4.636-4.66zM21.26 9.284L24 12l-2.74 2.715-2.717-2.715 2.717-2.715zM7.353 10.08L4.636 7.364 11.988 0l7.353 7.353-2.717 2.716-4.636-4.659-4.635 4.659zM2.716 14.716L0 12l2.74-2.715 2.717 2.715-2.74 2.716zM12 15.76l-3.76-3.76L12 8.24l3.76 3.76-3.76 3.76z'/%3E%3C/g%3E%3C/svg%3E" }
    ]
  },
  depositSetting: {
    notice: "সঠিক তথ্য দিয়ে ডিপোজিট করুন, ৫-৩০ মিনিটে ব্যালেন্স যোগ হবে।",
    minDeposit: 50.00,
    depositMethods: [
      { id: 'bkash', name: 'Bkash', accountNumber: '01895266128', logoUrl: 'https://seeklogo.com/images/B/bkash-logo-FBB258B90F-seeklogo.com.png' },
      { id: 'nagad', name: 'Nagad', accountNumber: '01895266128', logoUrl: 'https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png' },
      { id: 'binance', name: 'Binance', accountNumber: '0x123...', logoUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%23181A20'/%3E%3Cg transform='translate(25,25) scale(2.0833)' fill='%23F0B90B'%3E%3Cpath d='M16.624 13.92l2.717 2.716-7.353 7.353-7.353-7.353 2.717-2.716 4.636 4.66 4.636-4.66zM21.26 9.284L24 12l-2.74 2.715-2.717-2.715 2.717-2.715zM7.353 10.08L4.636 7.364 11.988 0l7.353 7.353-2.717 2.716-4.636-4.659-4.635 4.659zM2.716 14.716L0 12l2.74-2.715 2.717 2.715-2.74 2.716zM12 15.76l-3.76-3.76L12 8.24l3.76 3.76-3.76 3.76z'/%3E%3C/g%3E%3C/svg%3E" }
    ]
  },
  spinSetting: {
    costPerSpin: 0,
    rewards: [
      { id: 'r1', amount: 10, probability: 1 },    // 1 in 1000
      { id: 'r2', amount: 5, probability: 2 },     // 1 in 500
      { id: 'r3', amount: 2, probability: 5 },
      { id: 'r4', amount: 1, probability: 10 },
      { id: 'r5', amount: 0.5, probability: 20 },
      { id: 'r6', amount: 0.2, probability: 50 },
      { id: 'r7', amount: 0.1, probability: 100 },
      { id: 'r8', amount: 0.05, probability: 200 },
      { id: 'r9', amount: 0.02, probability: 250 },
      { id: 'r10', amount: 0.01, probability: 362 },
    ]
  },
  referralSetting: {
    isEnabled: true,
    rewardAmount: 3.00,
  },
  contactSettings: {
    whatsapp: "https://wa.me/1234567890",
    telegram: "https://t.me/admin_username",
    youtube: "https://youtube.com/@channel"
  },
  updateGmailSetting: (newSetting) => 
    set((state) => ({ gmailSetting: { ...state.gmailSetting, ...newSetting } })),
  updateFacebookSetting: (newSetting) => 
    set((state) => ({ facebookSetting: { ...state.facebookSetting, ...newSetting } })),
  updateInstagramSetting: (newSetting) => 
    set((state) => ({ instagramSetting: { ...state.instagramSetting, ...newSetting } })),
  updateWhatsappSetting: (newSetting) => 
    set((state) => ({ whatsappSetting: { ...state.whatsappSetting, ...newSetting } })),
  updateWithdrawSetting: (newSetting) => 
    set((state) => ({ withdrawSetting: { ...state.withdrawSetting, ...newSetting } })),
  updateDepositSetting: (newSetting) => 
    set((state) => ({ depositSetting: { ...state.depositSetting, ...newSetting } })),
  updateSpinSetting: (newSetting) => 
    set((state) => ({ spinSetting: { ...state.spinSetting, ...newSetting } })),
  updateReferralSetting: (newSetting) => 
    set((state) => ({ referralSetting: { ...state.referralSetting, ...newSetting } })),
  updateContactSettings: (newSettings) =>
    set((state) => ({ contactSettings: { ...state.contactSettings, ...newSettings } })),
  updateUserBalance: (newBalance) => set({ userBalance: newBalance })
}));
