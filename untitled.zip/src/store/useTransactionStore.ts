import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type TransactionType = 'deposit' | 'withdraw';
export type TransactionStatus = 'pending' | 'success' | 'rejected';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  method: string;
  accountNumber: string;
  status: TransactionStatus;
  createdAt: string;
}

interface TransactionState {
  transactions: Transaction[];
  addTransaction: (transaction: Transaction) => void;
  updateTransactionStatus: (id: string, status: TransactionStatus) => void;
}

export const useTransactionStore = create<TransactionState>()(
  persist(
    (set) => ({
      transactions: [],
      addTransaction: (transaction) => set((state) => ({ transactions: [transaction, ...state.transactions] })),
      updateTransactionStatus: (id, status) => set((state) => ({
        transactions: state.transactions.map(t => 
          t.id === id ? { ...t, status } : t
        )
      }))
    }),
    {
      name: 'transaction-history-storage'
    }
  )
);
