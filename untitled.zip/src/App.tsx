import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './store/useAuthStore';

// Layouts
import UserLayout from './components/layouts/UserLayout';
import AdminLayout from './components/layouts/AdminLayout';

// Pages
import AuthPage from './pages/auth/AuthPage';
import UserDashboard from './pages/user/Dashboard';
import GmailSell from './pages/user/GmailSell';
import FacebookSell from './pages/user/FacebookSell';
import InstagramSell from './pages/user/InstagramSell';
import WhatsappSell from './pages/user/WhatsappSell';
import Wallet from './pages/user/Wallet';
import Deposit from './pages/user/Deposit';
import Spin from './pages/user/Spin';
import Profile from './pages/user/Profile';
import MicroJobs from './pages/user/MicroJobs';
import JobDetails from './pages/user/JobDetails';
import JobHistory from './pages/user/JobHistory';
import DailyTasks from './pages/user/DailyTasks';
import DailyTaskDetails from './pages/user/DailyTaskDetails';
import DailyTaskHistory from './pages/user/DailyTaskHistory';
import AdminDashboard from './pages/admin/Dashboard';
import AdminSettings from './pages/admin/Settings';
import AdminMicroJobs from './pages/admin/AdminMicroJobs';
import AdminDailyTasks from './pages/admin/AdminDailyTasks';
import AdminStore from './pages/admin/AdminStore';
import AdminTransactions from './pages/admin/AdminTransactions';
import Store from './pages/user/Store';
import PlatformHistory from './pages/user/PlatformHistory';
import Referrals from './pages/user/Referrals';

export default function App() {
  const { checkAuth, isLoading, user, isAdmin } = useAuthStore();

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Toaster position="top-center" />
      <Routes>
        <Route path="/auth" element={!user ? <AuthPage /> : <Navigate to={isAdmin ? "/admin/dashboard" : "/dashboard"} />} />
        
        {/* User Routes */}
        <Route path="/" element={user && !isAdmin ? <UserLayout /> : <Navigate to="/auth" />}>
          <Route index element={<Navigate to="/dashboard" />} />
          <Route path="dashboard" element={<UserDashboard />} />
          <Route path="wallet" element={<Wallet />} />
          <Route path="deposit" element={<Deposit />} />
          <Route path="spin" element={<Spin />} />
          <Route path="profile" element={<Profile />} />
          <Route path="referrals" element={<Referrals />} />
          <Route path="store" element={<Store />} />
          <Route path="history" element={<PlatformHistory />} />
          <Route path="micro-jobs" element={<MicroJobs />} />
          <Route path="job/:id" element={<JobDetails />} />
          <Route path="job-history" element={<JobHistory />} />
          <Route path="daily-tasks" element={<DailyTasks />} />
          <Route path="daily-task/:id" element={<DailyTaskDetails />} />
          <Route path="daily-task-history" element={<DailyTaskHistory />} />
          <Route path="services/gmail" element={<GmailSell />} />
          <Route path="services/facebook" element={<FacebookSell />} />
          <Route path="services/instagram" element={<InstagramSell />} />
          <Route path="services/whatsapp" element={<WhatsappSell />} />
        </Route>

        {/* Admin Routes */}
        <Route path="/admin" element={user && isAdmin ? <AdminLayout /> : <Navigate to="/auth" />}>
          <Route index element={<Navigate to="/admin/dashboard" />} />
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="settings" element={<AdminSettings />} />
          <Route path="jobs" element={<AdminMicroJobs />} />
          <Route path="daily-tasks" element={<AdminDailyTasks />} />
          <Route path="store" element={<AdminStore />} />
          <Route path="transactions" element={<AdminTransactions />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/auth" />} />
      </Routes>
    </BrowserRouter>
  );
}
