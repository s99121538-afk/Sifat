import { supabase, isSupabaseConfigured } from './supabase';

export const handleReferralBonus = async (userId: string, referralSetting: { isEnabled: boolean, rewardAmount: number }) => {
  if (!isSupabaseConfigured || !referralSetting.isEnabled || referralSetting.rewardAmount <= 0) return;

  try {
    // get user to check if they have referredBy and hasTriggeredReferralReward = false
    const { data: userProfile } = await supabase.from('profiles').select('*').eq('id', userId).single();
    if (!userProfile) return;

    if (userProfile.referredBy && !userProfile.hasTriggeredReferralReward) {
      // Find the referrer
      const { data: referrerProfile } = await supabase.from('profiles').select('*').eq('referralCode', userProfile.referredBy).single();
      
      if (referrerProfile) {
        // Give referrer the reward
        const currentReferralEarnings = referrerProfile.referralEarnings || 0;
        const currentTotalReferrals = referrerProfile.totalReferrals || 0;
        const currentBalance = referrerProfile.balance || 0;

        await supabase.from('profiles').update({
          balance: currentBalance + referralSetting.rewardAmount,
          referralEarnings: currentReferralEarnings + referralSetting.rewardAmount,
          totalReferrals: currentTotalReferrals + 1
        }).eq('id', referrerProfile.id);

        // Mark the new user as triggered
        await supabase.from('profiles').update({
          hasTriggeredReferralReward: true
        }).eq('id', userId);
      }
    }
  } catch (error) {
    console.error('Failed to handle referral bonus', error);
  }
};
